<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class BaseProductModel extends Model
{
    protected $table = 'tbl_base_product';

    const CREATED_AT = 'date_added';

    const UPDATED_AT = 'date_modified';

    protected $casts = [
	    // 'price' => 'integer',
	];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'product_type_id',
        'cpu_id',
        'ssd_id',
        'ssd_type_id',
        'display_size_id',
        'ram_id',
        'graphic_card_id',
        'model_id',
        'hdd_id',
        'os_id',
        'brand_id',
        'notes',
        'sku',
        'upc',
        'display_title',
        'is_active',
        'is_lock',
        'price',
        'category_id',
        'is_feature_product',
        'is_latest_product',
        'is_recomended',
        'feature',
        'specification',
        'offer',
        'warranty',
        'support',
        'media',
        'recently_searched_on',
        'view_count',
        'is_g_memrchant_product',
        
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [];

    public function getCategoryIdAttribute($value)
    {
        # code...
        return array_map('intval', explode(',', $value));
    }

    public function setDisplayTitleAttribute($value)
    {
        # code...
        $this->attributes['display_title'] = ucwords(trim($value));
    }

    public function setSkuAttribute($value)
    {
        # code...
        $this->attributes['sku'] = strtoupper(trim($value));
    }

    public function product_images()
    {
        # code...
        return $this->hasMany('App\ProductImageModel','product_id','id');
    }

    public function default_product_image()
    {
        # code...
        return $this->hasOne('App\ProductImageModel','product_id','id')->where('main_image', 1);
    }

    public function linked_categories()
    {
        # code...
        return $this->hasMany('App\ProductCategoryModel','product_id','id');
    }

    public function wishList(){
        # code ...
        return $this->hasOne('App\WishListModel','product_id','id');
    }

    public function cartList(){
        return $this->hasOne('App\CartModel','product_id','id');
    }

    //product configuration details
    public function cpu(){
        return $this->hasOne('App\MasterDataValueModel','value_id','cpu_id');
    }

    public function ssd(){
        return $this->hasOne('App\MasterDataValueModel','value_id','ssd_id');
    }

    public function ssd_type(){
        return $this->hasOne('App\MasterDataValueModel','value_id','ssd_type_id');
    }

    public function hdd(){
        return $this->hasOne('App\MasterDataValueModel','value_id','hdd_id');
    }

    public function model(){
        return $this->hasOne('App\MasterDataValueModel','value_id','model_id');
    }

    public function os(){
        return $this->hasOne('App\MasterDataValueModel','value_id','os_id');
    }

    public function ram(){
        return $this->hasOne('App\MasterDataValueModel','value_id','ram_id');
    }

    public function display(){
        return $this->hasOne('App\MasterDataValueModel','value_id','display_size_id');
    }

    public function graphic(){
        return $this->hasOne('App\MasterDataValueModel','value_id','graphic_card_id');
    }

    public function brand(){
        return $this->hasOne('App\MasterDataValueModel','value_id','brand_id');
    }

    public function productType(){
        return $this->hasOne('App\MasterDataValueModel','value_id','product_type_id');
    }

    public function orders(){
        return $this->hasOne('App\OrderModel','product_id','id');   
    }

    public function configuration(){
        return $this->hasMany('App\ConfigurationModel','product_id','id');
    }

    public function feedbacks(){
        return $this->hasMany('App\FeedbackModel','product_id','id')->where('is_approved',1);
    }

    public function product_base_configuration_storage(){
        return $this->hasOne('App\ResearchDataModel','product_id','id');
    }

    public function product_base_configuration_ram(){
        return $this->hasOne('App\ResearchDataModel','product_id','id');
    }

    public function product_base_configuration_os(){
        return $this->hasOne('App\ResearchDataModel','product_id','id');
    }
}