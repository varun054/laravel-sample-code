<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShippingBillingAddressModel extends Model
{
    protected $table = 'tbl_website_billing_shipping_addresses';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id',
        'name',
        'address_line_1',
        'address_line_2',
        'city',
        'state',
        'country',
        'zip_code',
        'landmark',
        'mobile_no',
        'address_type',
        'is_deleted',
        'is_default',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
    ];

    /*getter setter methods*/
    public function setNameAttribute($value)
    {
        $this->attributes['name'] = ucwords($value);
    }

    public function setAddressLine1Attribute($value)
    {
        $this->attributes['address_line_1'] = ucwords($value);
    }

    public function setAddressLine2Attribute($value)
    {
        if (!empty($value))
            $this->attributes['address_line_2'] = ucwords($value);
    }

    public function setCityAttribute($value)
    {
        $this->attributes['city'] = ucwords($value);
    }

    public function setStateAttribute($value)
    {
        $this->attributes['state'] = ucwords($value);
    }

    /*relationship methods*/
    public function country_details(){
        return $this->hasOne('App\CountryModel','id','country');
    }
}
