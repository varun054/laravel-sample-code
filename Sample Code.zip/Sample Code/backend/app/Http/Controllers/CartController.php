<?php

namespace App\Http\Controllers;

use App\Http\Controllers\{Controller,ProductController};
use Illuminate\Http\Request;
use App\Http\Requests;
use Exception,Validator,DB;

// repository
use App\Repository\{CartRepository,WishListRepository,ConfigurationRepository};

// model
use App\{BaseProductModel,CartModel,ShippingBillingAddressModel};


class CartController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | WishList Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the request relatetd to shipping and billing address for user.
    | 
    */

    private $request;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $Request, CartRepository $CartRepository, WishListRepository $WishListRepository,ProductController $ProductController)
    {
        $this->request = $Request;

        $this->cart = $CartRepository;

        $this->wishlist=$WishListRepository;

        $this->product_images_display_path = url('/public').config('app.img_path.product_images');

        $this->productController=$ProductController;
    }

    /**
     *  Function to move item to cart from wishlist.
     *
     *  @param : null.
     *
     *  @return : JSON response
     *
     *  Created By : Yashwant | Created On : 15 Oct 2018
    **/
    public function addItemToCart(ConfigurationRepository $ConfigurationRepository){
        try{
            $validator = Validator::make($this->request->all(), [
                'user_id' => 'required | numeric',
                'product_id' => 'required | numeric',
                'number_of_items' => 'required | numeric',
                // 'flag' => 'required',
            ]);

            if ($validator->fails())
            {
                foreach ($validator->messages()->getMessages() as $field_name => $messages){
                    throw new Exception($messages[0], 1);
                }
            }

            $add_to_cart_response = $this->cart->createUpdateData(['user_id' => $this->request->user_id,'product_id'=>$this->request->product_id],$this->request->all());

            if($this->request->flag == 'cart')
            {
                $this->wishlist->removeItem(['id'=>$this->request->wishlist_id]);    
            }elseif($this->request->flag == 'configuration')
            {
                $ConfigurationRepository->removeItem(['id' => $this->request->id]);
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Item moved to Cart Successfully'
            ], 200);   
        }   
        catch (\Exception $ex){
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200);
        }
    }


    /**
     *  Function to move item to cart from localstorage.
     *
     *  @param : null.
     *
     *  @return : JSON response
     *
     *  Created By : Yashwant | Created On : 23 Oct 2018
    **/
    public function addItemArrayToCart(CartRepository $CartRepository){
        try{
            $validator = Validator::make($this->request->all(), [
                'user_id' => 'required | numeric',
                'productCartArray' => 'required'
            ]);

            if ($validator->fails())
            {
                foreach ($validator->messages()->getMessages() as $field_name => $messages){
                    throw new Exception($messages[0], 1);
                }
            }
            
            if(count($this->request->productCartArray) == 0)
            {
                throw new Exception("Empty array found in cart array", 1);
            }

            foreach ($this->request->productCartArray as $product)
            {
                $add_to_cart_response = $this->cart->createUpdateData([
                    'user_id' => $this->request->user_id,
                    'product_id' => $product['product_id'],
                    'kit_id' => @$product['kit_id'],
                ],[
                    'number_of_items' => $product['number_of_items'],
                    'kit_price' => @$product['kit_price'],
                    'kit_desc' => @$product['kit_desc'],
                ]);
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Product Added to Cart successfully'
            ], 200);   
        }   
        catch (\Exception $ex){
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200);
        }
    }    

    /**
     *  Function to get user cart data.
     *
     *  @param : user_id.
     *
     *  @return : JSON response
     *
     *  Created By : Yashwant | Created On : 17 Oct 2018
    **/
    public function getProductCartList($user_id){
        try{
            $cart_response_data=$this->cart->getData(['user_id'=>$user_id],'get',['products','productImages']);

            $tempArray=$cart_response_data;

            $index=0;
            foreach ($tempArray as $temp) {
                # code...
                $rating=$this->productController->getFeedbackRating($temp['product_id']);
                $tempArray[$index]['rating']=$rating;
                $index++;
            }
            $cart_response_data=$tempArray;

            return response()->json([
                'status' => 'success',
                'data' => $cart_response_data,
                'count' => count($cart_response_data),
                'path' => $this->product_images_display_path
            ], 200);
        }
        catch (\Exception $ex){
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200);
        }
    }

    /**
     *  Function to remove item from cart.
     *
     *  @param : id.
     *
     *  @return : JSON response
     *
     *  Created By : Yashwant | Created On : 17 Oct 2018
    **/
    public function removeItemFromCart($id){
        try{
            $delete_cart_item_response=$this->cart->removeItem(['id'=>$id]);

            return response()->json([
                'status' => 'success',
                'message' => 'Cart Item Removed Successfully'
            ], 200);
        }
        catch (\Exception $ex){
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200);
        }
    }

    /**
     *  Function to update cart quantity.
     *
     *  @param : id.
     *
     *  @return : JSON response
     *
     *  Created By : Yashwant | Created On : 17 Oct 2018
    **/
    public function UpdateShoppingCart(CartRepository $CartRepository){
        try{
            $cartDataArray=$this->request->cartData;

            foreach ($cartDataArray as $cartData) {
                $update_shopping_cart_response=$this->cart->createUpdateData(['id'=>$cartData['id']],['number_of_items'=>$cartData['number_of_items']]);
            }
            
            return response()->json([
                'status' => 'success',
                'data' => 'Cart updated successfully'
            ], 200);
        }
        catch (\Exception $ex){
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200);
        }
    }


    /**
     *  Function to get checkout data.
     *
     *  @param : user_id.
     *
     *  @return : JSON response
     *
     *  Created By : Yashwant | Created On : 22 Oct 2018
    **/
    public function getUserCheckoutData($user_id){
        try{
            $cart_checkout_response_data = $this->cart->getData(['user_id'=>$user_id],'get',[
                'products',
                'products.cpu',
                'products.ssd',
                'products.ssd_type',
                'products.hdd',
                'products.os',
                'products.ram',
                'products.display',
                'products.graphic',
                'products.productType',
                'productImages'
                /*'user.billingAddress',
                'user.shippingAddress'*/
            ]);

            $billing_address = ShippingBillingAddressModel::where([
                'user_id' => $user_id,
                'address_type' => 'billing',
                'is_default' => 1,
            ])->first();

            $shipping_address = ShippingBillingAddressModel::where([
                'user_id' => $user_id,
                'address_type' => 'shipping',
                'is_default' => 1,
            ])->first();

            
            if(count($cart_checkout_response_data)>0){
                foreach ($cart_checkout_response_data as $key => $temp) {
                    $rating=$this->productController->getFeedbackRating($temp['product_id']);
                    $cart_checkout_response_data[$key]['rating']=$rating;

                    if (!empty($temp['kit_id'])) {
                        $kit_data = DB::select("select * from tbl_kit where id = ".$temp['kit_id']." UNION select * from tbl_kit_archive where id = ".$temp['kit_id']."");
                    } else {
                        $kit_data = null;
                    }                    

                    $cart_checkout_response_data[$key]['kit_data'] = (empty($kit_data)) ? null : $kit_data[0];
                }
            }            

            return response()->json([
                'status' => 'success',
                'data' => $cart_checkout_response_data,
                'count' => count($cart_checkout_response_data),
                'path' => $this->product_images_display_path,
                'billing_address' => $billing_address,
                'shipping_address' => $shipping_address,
            ], 200);
        }
        catch (\Exception $ex){
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200);
        }
    }
}