<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use App\CategoryModel;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function getParentId($category_id)
    {
        # code...
        $data = CategoryModel::where('id', $category_id)->first();

        if (!empty($data) && !empty($data->parent_category_id)) {
            # code...
            return $this->getParentId($data->parent_category_id);
        }else{
            return $data->id;
        }
    }
}
