<?php
namespace App\Repository;

interface RepositoryInterface
{
    public function getData($conditions, $method, $withArr = []);

    public function createUpdateData($conditions, $parameters);
}