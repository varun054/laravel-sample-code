<?php
namespace App\Repository;

use App\Repository\RepositoryInterface;
use App\ConfigurationModel;
use Carbon\Carbon;
use File;
use Exception;

class ConfigurationRepository implements RepositoryInterface
{
    private $model;

    private $product_images_upload_path;

    public function __construct(ConfigurationModel $ConfigurationModel)
    {
        # code...
        // $this->model = $ProductModel;
        $this->model = $ConfigurationModel;

        $this->product_images_upload_path = public_path().config('app.img_path.product_images');
    }

     public function createUpdateData($condition, $parameters)
    {
        # code...
        return $resultSet = $this->model->updateOrCreate($condition, $parameters);
    }

    public function getData($conditions, $method, $withArr = [])
    {
        # code...
        $query = $this->model->whereNotNull('id');

        if (!empty($conditions['id'])) {
            # code...
            $query->where('id', $conditions['id']);
        }

        if (!empty($conditions['user_id'])) {
            # code...
            $query->where('user_id', $conditions['user_id']);
        }

        if (!empty($withArr)) {
            # code...
            $query->with($withArr);
        }

        $resultSet = $query->orderBy('id', 'desc')->$method();

        if (!empty($resultSet)) {
            # code...
            $resultSet = $resultSet->toArray();
        }

        return $resultSet;
    }

    public function removeItem($conditions)
    {
        $this->model->where($conditions)->delete();
        
        return true;
    }
}