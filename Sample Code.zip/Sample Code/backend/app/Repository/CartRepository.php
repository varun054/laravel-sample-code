<?php
namespace App\Repository;

use App\Repository\RepositoryInterface;
use App\CartModel;
use Carbon\Carbon;
use Exception;

class CartRepository implements RepositoryInterface
{
    private $model;

    public function __construct(CartModel $CartModel)
    {
        # code...
        $this->model = $CartModel;
    }

    public function create($parameters)
    {
        return $resultSet = $this->model->create($parameters);
    }

    public function createUpdateData($condition, $parameters)
    {
        # code...
        return $resultSet = $this->model->updateOrCreate($condition, $parameters);
    }

    public function getData($conditions, $method, $withArr = [])
    {
        # code...
        $query = $this->model->where('user_id',$conditions['user_id']);

        if (!empty($conditions['user_id'])) {
            # code...
            $query->where('user_id', $conditions['user_id']);
        }

        if (!empty($conditions['product_id']))
        {
            $query->where('product_id', $conditions['product_id']);
        }

        if (!empty($withArr)) {
            # code...
            $query->with($withArr);
        }

        $resultSet = $query->orderBy('id', 'desc')->$method();

        if (!empty($resultSet)) {
            # code...
            $resultSet = $resultSet->toArray();
        }

        return $resultSet;
    }

    public function count($conditions)
    {
        $count = $this->model->where($conditions)->count();

        return $count;
    }

    public function removeItem($conditions){
    	try{
    		$query=$this->model->find($conditions['id']);
	    	$query->delete();
	    	return true; 
    	}
    	catch (\Exception $ex){
            return response()->json([
                'status' => 'error',
                'message' => 'Error : '.$ex->getMessage(),
                'error_details' => 'on line : '.$ex->getLine().' on file : '.$ex->getFile(),
            ], 200);
        }
    	
    }
}