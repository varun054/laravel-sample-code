<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class CartModel extends Model
{
    protected $table = 'tbl_website_user_cart';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'product_id',
        'user_id',
        'number_of_items',
        'kit_price',
        'kit_id',
        'kit_desc'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [];

    
    public function products()
    {
        # code...
        // return $this->belongsTo('App\ProductModel','product_id','id');
        return $this->belongsTo('App\BaseProductModel','product_id','id');
    }

    public function productImages(){
        # code ...
        return $this->hasOne('App\ProductImageModel','product_id','product_id')->where('main_image',1);
    }

    public function getKitDescAttribute($value){
        # code ...
        return json_decode($value);
    }

    public function setKitDescAttribute($value){
        # code ...
        $this->attributes['kit_desc'] = json_encode($value);
    }

    public function user(){
        return $this->belongsTo('App\User','user_id','id');
    }
}
