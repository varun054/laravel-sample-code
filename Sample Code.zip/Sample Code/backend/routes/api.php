<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
// route to generate invoice...

Route::get('generate-invoice/{order_id}', 'Admin\OrderController@generateInvoice');

Route::prefix('auth')->group(function () {

	$controller = 'AuthController@';

	Route::post('/do-authenticate-user', $controller.'doAuthenticateUser');

	Route::post('/do-register-user', $controller.'doRegisterUser');
});

Route::prefix('password')->group(function () {

	$controller = 'ForgotAndResetPasswordController@';

	Route::post('/forgot-password', $controller.'forgotPassword');

	Route::post('/reset-password', $controller.'resetPassword');

	Route::post('/change-password', $controller.'changePassword')->middleware(['auth:api']);

	Route::post('/change-password-by-admin', $controller.'changePasswordByAdmin')->middleware(['auth:api']);
});

Route::middleware(['auth:api'])->group(function () {
	
	/*
     *	For admin routes
    **/    
	Route::prefix('admin')->group(function () {	
	    include_once(__DIR__.'/route/admin_routes.php');
	});

	/*
     *	For user routes
    **/
	Route::prefix('user')->group(function () {	
	    include_once(__DIR__.'/route/user_routes.php');
	});

});

Route::prefix('seller-cloud')->group(function () {	
    
    $controller = 'SellerCloudController@';

    Route::get('/show', $controller.'show');

    Route::get('/get-order-details/{order_id}', $controller.'getOrderDetails');

    // Route::get('/get-order-shipping-status',$controller.'getOrderShippingStatus');
});

Route::prefix('master')->group(function () {

	$controller = 'MasterController@';

	Route::get('/get-phone-codes', $controller.'getPhoneCodes');

	Route::get('/get-country-names',$controller.'getCountryNames');

	Route::get('/get-static-file-path',$controller.'getStaticFilePath');

	Route::get('/get-brands',$controller.'getBrands');

	Route::get('/get-categories',$controller.'getCategoryTree');

	Route::get('/get-categories-children/{category_id?}',$controller.'getCategoryWithChildren');

	Route::get('/get-master-field-data',$controller.'getMasterFieldData');

	Route::get('/get-subscriber-list',$controller.'getSubscriberList');

	Route::post('/get-shipping-charges-details',$controller.'getDistance');

	Route::post('/cms/get-cms-data',$controller.'getCmsData');
});

Route::prefix('user-products')->group(function () {

	$controller = 'ProductController@';

	Route::post('/get-featured-products', $controller.'getFeaturedProducts');

	Route::post('/get-latest-products', $controller.'getLatestProducts');

	Route::post('/get-particular-product', $controller.'getParticularProductDetails');

	Route::post('/get-resent-products', $controller.'getRecentProducts');

	Route::post('/get-popular-products', $controller.'getPopularProducts');

	Route::get('/set-product-search-history/{id}', $controller.'setProductSearchHistory');
});

Route::prefix('search')->group(function () {

	$controller = 'SearchController@';

	Route::post('/get-products-filter', $controller.'getProductsFilter');

	Route::get('/get-category-filter/{category_id}', $controller.'getCategoryFilter');
});


Route::prefix('cart')->group(function () {

	$controller = 'ProductController@';

	Route::get('/get-local-product-cart-data', $controller.'getLocalProductCartData');
});


Route::prefix('product-customization')->group(function () {

    $controller = 'CustomizationController@';

    Route::get('/get-product-customization-data/{product_id}', $controller.'getProductCustomizationData');

    Route::post('/get-kit-details', $controller.'getKitDetails');

    Route::post('/product-customization-add-to', $controller.'productCustomizationAddTo')->middleware(['auth:api']);

    Route::post('/email-us', $controller.'emailUs');
});

Route::prefix('socialite')->group(function(){
	
	$controller = 'SocialiteController@';

	Route::post('facebook-login',$controller.'facebookLogin');
	
	Route::post('google-login',$controller.'googleLogin');
});


Route::prefix('contact')->group(function(){

	$controller = 'Admin\ContactRequestController@';

	Route::post('create-contact-request', $controller.'createContactUsRequest');

	Route::post('get-contact-request-list', $controller.'getContactRequestList')->middleware(['auth:api']);

	Route::post('delete-multiple-contact-request', $controller.'deleteMultipleContactRequest')->middleware(['auth:api']);
});

Route::prefix('faq')->group(function(){

    $controller='Admin\FaqController@';

    Route::post('/get-faq-data',$controller.'getFaqData');

    Route::get('/get-selected-faq-data/{filter}',$controller.'getSelectedFaqData');
});

Route::prefix('subscription')->group(function(){

	$controller='SubscriptionController@';

	Route::post('/subscribe-user',$controller.'subscribeUserEmail');

	Route::get('/un-subscribe-user/{email}',$controller.'unsubscribeNewsletter');
});

Route::prefix('menu')->group(function(){
	$controller='ProductController@';

	Route::post('/get-laptop-and-tablets',$controller.'getLaptopsAndTablets');
});

Route::get('/send-news-letter/{parameters}','MailController@sendNewsLettersToSubscribers');



// testing route
// Route::get('/index','AuthController@index');