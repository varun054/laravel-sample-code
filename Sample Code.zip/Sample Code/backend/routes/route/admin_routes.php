<?php

use Illuminate\Http\Request;

Route::get('/rating/{product_id}','ProductController@getFeedbackRating');

// for CMS relaeted queries...
    Route::prefix('cms')->group(function () {

        $controller = 'Admin\CMSController@';

        Route::get('/get-cms-list', $controller.'getCmsList');

        Route::get('/get-cms-detail/{id}', $controller.'getCmsDetail');

        Route::post('/update-cms-detail', $controller.'updateCMSDetail');
    });

// for category related routes
	Route::prefix('category')->group(function () {

        $controller = 'Admin\CategoryController@';

        Route::post('/add-category', $controller.'addEditCategory');

        Route::post('/edit-category', $controller.'addEditCategory');

        Route::post('/delete-category', $controller.'deleteCategory');

        Route::get('/get-category/{category_id}', $controller.'getCategory');

        Route::get('/get-categories', $controller.'getCategories');

        Route::get('/get-category-tree', $controller.'getCategoryTree');

        Route::post('/publish-unpublish', $controller.'publishUnpublish');
    });

// for sub-category related routes
    Route::prefix('sub-category')->group(function () {

        $controller = 'Admin\SubCategoryController@';

        Route::post('/add-sub-category', $controller.'addEditSubCategory');

        Route::post('/edit-sub-category', $controller.'addEditSubCategory');

        Route::post('/delete-sub-category', $controller.'deleteSubCategory');

        Route::get('/get-sub-category/{sub_category_id}', $controller.'getSubCategory');

        Route::get('/get-sub-categories/{category_id?}', $controller.'getSubCategories');
    });

// for dashboard related routes
    Route::prefix('dashboard')->group(function () {

        $controller = 'Admin\DashboardController@';

        Route::get('/get-dashboard-widget-data', $controller.'getDashboardWidgetData');
    });

//  for user management routes
    Route::prefix('user-manage')->group(function(){

        $controller='Admin\UserManagementController@';

        Route::post('/user-data',$controller.'getUserData');

        Route::post('/admin-data',$controller.'getAdminData');

        Route::post('/do-update-profile-picture',$controller.'doUpdateProfilePicture');
        
        Route::get('/get-profile-data/{user_id}',$controller.'getProfileData');

        Route::post('/delete-user-data',$controller.'deleteUserData');

        Route::post('/update-profile',$controller.'updateProfileData');

        Route::post('/add-admin',$controller.'addAdmin');

        Route::get('/delete-user-permanently/{user_id}',$controller.'deleteUserPermanently');

        Route::post('/delete-multiple-user-permanently',$controller.'deleteMultipleUserPermanently');
    });

//  for product management routes
    Route::prefix('product-manage')->group(function(){

        $controller='Admin\ProductController@';
        
        Route::post('/add-product',$controller.'addProductData');

        Route::post('/edit-product',$controller.'editProductData');

        Route::get('/delete-product/{product_id}',$controller.'deleteProductData');

        Route::get('/delete-product-image/{product_image_id}',$controller.'deleteProductImage');

        Route::get('/get-product-details/{product_id}',$controller.'getProductDetails');

        Route::post('/get-product-listing',$controller.'getProductListing');

        Route::post('/product-upload-excel',$controller.'productUploadThroughExcel');

        Route::post('/make-image-default',$controller.'makeImageAsDefault');

        Route::post('/mark-as-featured',$controller.'markAsFeatured');

        Route::post('/mark-as-latest',$controller.'markAsLatest');

        Route::post('/mark-as-recommended',$controller.'markAsRecommended');

        Route::post('/add-edit-product-other-info',$controller.'addEditProductOtherInfo');

        Route::post('/active-inactive',$controller.'activeInactiveProduct');

        Route::post('/add-product-google-shopping', 'GoogleMerchantController@addProductToGoogleMerchant');

        Route::post('/remove-product-google-shopping', 'GoogleMerchantController@removeProductToGoogleMerchant');
    });

//for orders management
    Route::prefix('orders')->group(function(){

        $controller='Admin\OrderController@';
        
        Route::post('/get-orders-data',$controller.'displayOrderData');

        Route::get('/get-order-details/{order_id}',$controller.'getOrderPaymentDetails');

        Route::post('/change-order-status',$controller.'changeOrderStatus');

        // Route::get('/get-user-order/{user_id}',$controller.'displayOrderData');

        Route::post('/add-update-order-detail-comment',$controller.'addUpdateOrderDetails');
    });

//for email templates relaetd routes
    Route::prefix('email')->group(function(){

        $controller='Admin\EmailTemplateController@';
        
        Route::get('/get-email-templates',$controller.'getEmailTemplates');

        Route::get('/get-email-template-data/{id}', $controller.'getEmailTemplate');

        Route::post('/update-email-template-data', $controller.'updateEmailTemplateData');
    });

//for FAQ management
    Route::prefix('faq')->group(function(){

        $controller='Admin\FaqController@';

        // Route::get('/get-faq-data',$controller.'getFaqData');

        Route::post('/add-update-faq-data',$controller.'addUpdateFaqs');

        Route::get('/get-edit-faq-data/{id}',$controller.'getEditFaqData');

        Route::get('/delete-faq-data/{id}',$controller.'deleteFaqData');

        Route::post('/publish-unpublish-faq-data',$controller.'publishUnpublishFaq');
    });

//for Feedback management
    Route::prefix('feedback')->group(function(){

        $controller='FeedbackController@';

        Route::post('/get-feedback-data',$controller.'getAllFeedbackData');

        Route::get('/delete-feedback/{id}',$controller.'deleteFeedback');

        Route::post('/approve-disapprove-feedback',$controller.'approveDisapproveFeedback');
    });

//for subscriber management
    Route::prefix('subscriber')->group(function(){

        $controller='SubscriptionController@';

        Route::post('/get-subscriber',$controller.'getAllSubscriberData');

        Route::get('/delete-subscriber/{id}',$controller.'deleteSubscriber');

        Route::post('/delete-multiple-subscriber',$controller.'deleteMultipleSubscriber');

        Route::post('/add-edit-template',$controller.'addEditTemplate');

        Route::get('/get-templates',$controller.'getTemplates');

        Route::get('/get-template-detail/{id}',$controller.'getTemplates');

        Route::get('/delete-template/{id}',$controller.'deleteTemplate');

        Route::post('/send-test-mail',$controller.'sendTestMail');

        Route::post('/newsletter-mail-request',$controller.'newsletterMailRequest');
    });

//for coupan management
    Route::prefix('coupan-manage')->group(function(){

        $controller='Admin\CoupanController@';

        Route::post('/get-coupan-data',$controller.'getCoupanData');

        // Route::get('/edit-coupan-data/{id}',$controller.'getEditCoupanData');

        Route::post('/add-update-coupan-data',$controller.'addUpdateCoupanData');

        Route::post('/delete-coupan-data',$controller.'deleteCoupanData');

        Route::post('/activate-deactivate-coupan-data',$controller.'activateDeactivateCoupan');
    });

//for Email us
    Route::prefix('email-us')->group(function(){

        $controller='Admin\EmailUsController@';

        Route::post('/get-email-us',$controller.'getEmailUsList');
    });

//for shipping sharges
    Route::prefix('shipping-charges')->group(function(){

        $controller='Admin\ShippingChargesController@';

        Route::post('/set-shipping-charges', $controller.'setShippingCharges');

        Route::get('/get-record/{id?}', $controller.'getRecord');

        Route::get('/delete/{id?}', $controller.'delete');

        Route::get('/get-details-by-km/{km}', $controller.'getDetails');
    });