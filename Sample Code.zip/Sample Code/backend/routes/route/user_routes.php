<?php

use Illuminate\Http\Request;

// for category related routes
	Route::prefix('shipping-billing-address')->group(function () {

        $controller = 'ShippingBillingAddressController@';

        Route::post('/store-address', $controller.'storeAddress');

        Route::post('/edit-address', $controller.'storeAddress');

        Route::get('/get-address/{address_id}', $controller.'getAddress');

        Route::post('/get-all-addresses', $controller.'getAddresses');

        Route::post('/delete-address', $controller.'deleteAddress');

        Route::post('/set-default-address', $controller.'setDefaultAddress');

        Route::post('/copy-address', $controller.'copyAddress');

    });

// for authoroze.net payment related routes
    Route::prefix('authorize')->group(function () {

        $controller = 'AuthorizeController@';

        Route::post('do-process-order', $controller.'doProcessOrder');
    });

// for amazon pay related routes
    Route::prefix('amazon-pay')->group(function () {

        $controller = 'AmazonPayController@';

        Route::post('do-process-order', $controller.'doProcessOrder');
    });

    Route::prefix('')->group(function () {

		$controller='WishListController@';

	    Route::get('wishlist/{user_id}',$controller.'getWishList');

        Route::get('remove-item-from-wishList/{id}',$controller.'removeItemFromWishList');

	    Route::post('move-to-wish-list',$controller.'moveItemToList');

        // Route::get('count-wish-list/{id}',$controller.'wishListCount');

	    $controller2='CartController@';

	    Route::post('add-item-to-cart', $controller2.'addItemToCart');

        //add product array from localstorage
        Route::post('add-item-array-to-cart',$controller2.'addItemArrayToCart');

        Route::post('add-data-to-wishList',$controller.'addDataToWishList');

        Route::get('get-user-cart-data/{user_id}',$controller2.'getProductCartList');

        Route::get('get-user-checkout-data/{user_id}',$controller2.'getUserCheckoutData');

        Route::get('remove-item-from-cart/{id}',$controller2.'removeItemFromCart');

        Route::post('update-shopping-cart',$controller2.'UpdateShoppingCart');
	
	});

    Route::prefix('payment')->group(function () {

        $paypal='PaypalController@';

        Route::post('paypal-payment', 'PaypalController@addPaymentInfo');

        Route::get('refund',$paypal.'refund');
    });

    Route::prefix('orders')->group(function () {

        $order='Admin\OrderController@';

        Route::get('generate-invoice/{order_id}',$order.'generateInvoice');

        // Route::get('get-order-list/{userId}',$order.'getOrderList');
        
        Route::post('get-order-list',$order.'displayOrderData');

        Route::post('get-user-order-details', $order.'getUserOrderDetails');

        Route::get('do-cancel-order/{order_id}', $order.'doCancelOrder');
    });

    Route::prefix('configuration')->group(function () {
        
        $configuration='ConfigurationController@';

        Route::post('get-configuration-data',$configuration.'getConfigurationData');

        Route::post('get-configuration-detail',$configuration.'getConfigurationDetails');

        Route::post('remove-configuration',$configuration.'removeConfiguration');
    });

    Route::prefix('feedback')->group(function () {
        
        $controller='FeedbackController@';

        Route::post('add-update-product-order-feedback',$controller.'addUpdateFeedback');

        Route::post('get-feedback-data',$controller.'getFeedbackData');
    });

    Route::prefix('user-coupan')->group(function () {
        
        $controller='Admin\CoupanController@';

        Route::post('check-coupan-applied',$controller.'checkCoupanApplied');
    });



    // Route::prefix('order')->group(function(){
    //     // $controller='OrderController@';

    //     Route::get('get-order-list/{userId}','OrderController@getOrderList');
    // });

    

    // Route::prefix('payment')->group(function(){
    //     $paypalController='PaypalController@';

    //     Route::get('payment-status',$paypalController.'paymentInfo');

    //     Route::get('payment',$paypalController.'payment'));
    // });