export const adminLteConf = {
  skin: 'blue',
  
  sidebarLeftMenu: [
    // {label: 'MAIN NAVIGATION', separator: true},
    {label: 'Dashboard', route: '/admin', iconClasses: 'fa fa-tachometer'},
    {label: 'Category', route: '/admin/category', iconClasses: 'fa fa-address-book'},
    // {label: 'Sub-Category', route: '/admin/sub-category', iconClasses: 'fa fa-address-book-o'},
    {label: 'User Management',route:'/admin/user-manage', iconClasses: 'fa fa-user'},

    //{label: 'User Management',route:'/admin/user-manage', iconClasses: 'fa fa-user'},


    {label: 'Admin List',route:'/admin/admin-management', iconClasses: 'fa fa-user'},

    {label: 'My Profile',route:'/admin/profile', iconClasses: 'fa fa-user'},

    {label: 'Product List',route:'/admin/product', iconClasses: 'fa fa-user'},

    {label: 'Orders', route:'/admin/orders', iconClasses:'fa fa-shopping-cart'},
    {label: 'Email Tempates', route:'/admin/email-templates', iconClasses:'fa fa-envelope'},
    {label: 'Contact Request', route:'/admin/contact-request', iconClasses:'fa fa-address-book'},
    {label: 'FAQ', route:'/admin/faq', iconClasses:'fa fa-question-circle'},
    {label: 'Feedback', route:'/admin/feedback', iconClasses:'fa fa-comments'},
    {label: 'Subscriber', route:'/admin/subscriber', iconClasses:'fa fa-user'},
    {label: 'Coupon Management', route:'/admin/coupon', iconClasses:'fa fa-percent'},
    {label: 'Email Us Request', route:'/admin/email-us', iconClasses:'fa fa-envelope'},
    {label: 'CMS', route:'/admin/cms', iconClasses:'fa fa-envelope'},
    {label: 'Shipping Cost', route:'/admin/shipping-cost', iconClasses:'fa fa-dollar'},
  ]
};
