import { ResetPasswordComponent } from './modules/admin/authentication/reset-password/reset-password.component';
import {
    NgModule
} from '@angular/core';
import {
    Routes,
    RouterModule
} from '@angular/router';
import { PageNotFoundComponent } from './shared/page-not-found/page-not-found.component';

const routes: Routes = [
    {
        path: '',
        // pathMatch: 'full'
        loadChildren: './core/user/user-layout.module#UserLayoutModule',
        data: {
            title: 'Home',
            customLayout: true
        }
    },
    {
        path: 'admin',
        data: {
            title: 'Home',
        },
        children: [
            {
                path: '',
                loadChildren: './modules/admin/admin.module#AdminModule',
                data: {
                    title: 'Admin'
                }
            },
        ]
    },
    {
        path:'password/reset-password/:token',
        component:ResetPasswordComponent,
        data:{
          title:'Admin Reset Password',
          customLayout:true
        }
    },
    {
        path:'**',
        loadChildren:'./shared/page-not-found/page-not-found.module#PageNotFoundModule',
        data:{
          customLayout:true
        }
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes, {
        useHash: false
    })],
    exports: [RouterModule]
})
export class AppRoutingModule {}