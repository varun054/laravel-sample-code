import { ReactiveFormsModule } from '@angular/forms';
import { ResetPasswordComponent } from './modules/admin/authentication/reset-password/reset-password.component';
import { AdminGuardGuard } from './guards/admin-guard.guard';
import { MyInterceptor } from './shared/interceptor';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { adminLteConf } from './admin-lte.conf';

import { AppRoutingModule } from './app-routing.module';
import { CoreModule } from './core/core.module';

import { LayoutModule } from 'angular-admin-lte';

import { AppComponent } from './app.component';

import { LoadingPageModule, MaterialBarModule } from 'angular-loading-page';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AlertModule as MkAlertModule, BoxModule, BoxInfoModule as MkBoxInfoModule} from 'angular-admin-lte';
import { LoginGuard } from './guards/login.guard';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { UserGuard } from './guards/user.guard';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

@NgModule({
  imports: [
    BrowserModule,
    AppRoutingModule,
    CoreModule,
    LayoutModule.forRoot(adminLteConf),
    LoadingPageModule, MaterialBarModule,
    MkAlertModule,
    BoxModule,
    MkBoxInfoModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot()
  ],
  declarations: [
    AppComponent,
    ResetPasswordComponent,
  ],
  bootstrap: [AppComponent],
  providers: [
    {
    provide: HTTP_INTERCEPTORS,
    useClass: MyInterceptor,
    multi: true,
  },
  AdminGuardGuard,LoginGuard,UserGuard
  ],
})
export class AppModule {}
