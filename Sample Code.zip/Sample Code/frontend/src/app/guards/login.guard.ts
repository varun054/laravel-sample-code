import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import {Location } from '@angular/common'

@Injectable()
export class LoginGuard implements CanActivate {
  constructor(private location:Location){}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      var userData = JSON.parse(localStorage.getItem('userData'))
      if(userData != undefined||userData != null){
        this.location.back()
      }
    return true
  }
}