import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import {Location } from '@angular/common'
@Injectable()
export class AdminGuardGuard implements CanActivate {
  baseUrl:any
  constructor(private router:Router, private location:Location){}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      var userData = JSON.parse(localStorage.getItem('userData'));
      var token = JSON.parse(localStorage.getItem('token'));
      
      let domain_name=this.getRoute();

      if(userData == undefined || userData.length == 0 || userData == null || token==undefined || token==null || token.length==0){

          console.log(domain_name);
          // console.log(domain_name[0],'   ',domain_name[1])
          if(domain_name.indexOf('admin') > -1){
            this.router.navigate(['/admin/login'])
            
            localStorage.removeItem('token');
            localStorage.removeItem('userData');
            return false
          }
          

          this.router.navigate(['']);
          return false;
      }else{
        if (userData.role_id == 1) {
          return true;  
        } else {
          // this.router.navigate(['']);
          this.location.back()
          return false;
        }
        // if(domain_name[1]=='admin/login'){
          // return false;
        // }
      }

  }

  getRoute(){
    let url=window.location.href
    let protocol=url.split('://')
    let domain=protocol[1]
    let domain_name=domain.split('/')
    return domain_name
  }
}
