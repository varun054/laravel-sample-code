import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private url = environment.url;

  constructor(private http:HttpClient, private router:Router) { }

  getCMSLocalStorageData(flag) {
    let cms_data = JSON.parse(localStorage.getItem('CMS_data'));
    
    return cms_data[flag];
  }

  getProfileData(user_id) {
    return this.http.get(this.url + 'admin/user-manage/get-profile-data/'+user_id);
  }

  doUpdateProfiePicture(value){
      return this.http.post(this.url+'admin/user-manage/do-update-profile-picture',value);
  }

  updateUserData(value){
      return this.http.post(this.url+'admin/user-manage/update-profile',value)
  }

  getAddress(value){
    return this.http.post(this.url+'user/shipping-billing-address/get-all-addresses',value)
  }

  addAddress(value){
    return this.http.post(this.url+'user/shipping-billing-address/store-address',value)
  }

  editAddress(value){
    return this.http.get(this.url+'user/shipping-billing-address/get-address/'+value)
  }

  updateShippingBillingData(value){
    return this.http.post(this.url+'user/shipping-billing-address/edit-address',value)
  }

  deleteShippingBillingData(value){
    return this.http.post(this.url+'user/shipping-billing-address/delete-address',value)
  }

  getFeaturedProductData(value){
    return this.http.post(this.url+'user-products/get-featured-products',value)
  }

  getLatestProductData(value){
    return this.http.post(this.url+'user-products/get-latest-products',value)
  }

  getProductData(value){
    return this.http.post(this.url+'user-products/get-particular-product',value)
  }

  getRecentProducts(params)
  {
    return this.http.post(this.url+'user-products/get-resent-products', params)
  }

  getPopularProducts(params)
  {
    return this.http.post(this.url+'user-products/get-popular-products', params)
  }

  setProductSearchHistory(id)
  {
    return this.http.get(this.url+'user-products/set-product-search-history/'+id)
  }

  getWishListData(value){
    return this.http.get(this.url+'user/wishlist/'+value);
  }

  removeItemFromWishList(value){
    return this.http.get(this.url+'user/remove-item-from-wishList/'+value)
  }

  addToCart(value){
    return this.http.post(this.url+'user/add-item-to-cart',value)
  }

  addDataToWishList(value){
    return this.http.post(this.url+'user/add-data-to-wishList',value)
  }

  deleteFromWishList(value){
    return this.http.get(this.url+'user/remove-item-from-wishList/'+value)
  }

  getProductFilter(value){
    return this.http.post(this.url+'search/get-products-filter', value);
  }

  getCategoryFilter(value){
    return this.http.get(this.url+'search/get-category-filter/'+value);
  }

  setAsDefaultAddress(value){
    return this.http.post(this.url+'user/shipping-billing-address/set-default-address', value);
  }

  addProductToCart(value){
    return this.http.post(this.url+'user/add-item-to-cart', value);
  }

  getShoppingCartData(value){
    return this.http.get(this.url+'user/get-user-cart-data/'+value)
  }

  removeItemFromCart(value){
    return this.http.get(this.url+'user/remove-item-from-cart/'+value)
  }

  wishListCount(value){
    return this.http.get(this.url+'user/wishlist/'+value)
  }

  cartListCount(value){
    return this.http.get(this.url+'user/get-user-cart-data/'+value)
  }

  saveUpdatedCartData(value){
    return this.http.post(this.url+'user/update-shopping-cart', {cartData:value});
  }

  getCheckOutData(value){
    return this.http.get(this.url+'user/get-user-checkout-data/'+value)
  }

  getShippingPrice(params)
  {
    return this.http.post(this.url+'master/get-shipping-charges-details',params);
  }

  getProductCustomizationData(value){
    return this.http.get(this.url+'product-customization/get-product-customization-data/'+value)
  }

  getKitDetails(value){
    return this.http.post(this.url+'product-customization/get-kit-details', value);
  }

  productCustomizationAddTo(value){
    return this.http.post(this.url+'product-customization/product-customization-add-to', value);
  }

  addProductCartArray(value){
    return this.http.post(this.url+'user/add-item-array-to-cart',value)
  }

  getLocalCartData(){
    return this.http.get(this.url+'cart/get-local-product-cart-data')
  }

  paypalResponseData(data){
    return this.http.post(this.url+'user/payment/paypal-payment',{data})
  }

  getUserOrderData(params){
    return this.http.post(this.url+'user/orders/get-order-list', params)
  }

  doProcessOrderWithAuthorize(value){
    return this.http.post(this.url+'user/authorize/do-process-order', value);
  }

  getSavedConfiguration(params){
    return this.http.post(this.url+'user/configuration/get-configuration-data', params)
  }

  redirectToConfigurationDetails(id){
    this.router.navigate(['/my-configuration/'+id])    
  }

  getConfigurationDetails(value){
    return this.http.post(this.url+'user/configuration/get-configuration-detail',value)
  }

  removeConfigurationData(value){
    return this.http.post(this.url+'user/configuration/remove-configuration',value)
  }

  getUserOrderDetails(value){
    return this.http.post(this.url+'user/orders/get-user-order-details',value)
  }  

  //socialite
  facebookLogin(value){
    return this.http.post(this.url+'socialite/facebook-login',value)
  }

  googleLogin(value){
    return this.http.post(this.url+'socialite/google-login',value)
  }

  checkBillingShipping(value){
    return this.http.post(this.url+'user/shipping-billing-address/get-all-addresses',value)
  }

  generateInvoice(value){
    return this.http.get(this.url+'user/orders/generate-invoice/'+value);
  }

  contactUsRequest(value){
    return this.http.post(this.url+'contact/create-contact-request', value);
  }

  addFeedbackData(value){
    return this.http.post(this.url+'user/feedback/add-update-product-order-feedback', value);
  }
  
  doCancelOrder(order_id){
    return this.http.get(this.url+'user/orders/do-cancel-order/'+order_id);
  }

  getFeedbackData(value){
    return this.http.post(this.url+'user/feedback/get-feedback-data',value);
  }

  getSelectedFaqData(value){
    return this.http.get(this.url+'faq/get-selected-faq-data/'+value);
  }

  getLatestProductMail(){
    return this.http.get(this.url+'send-news-letter/1')
  }

  checkCoupanStatus(value){
    return this.http.post(this.url+'user/user-coupan/check-coupan-applied',value)
  }

  emailUs(value){
    return this.http.post(this.url+'product-customization/email-us', value);
  }

  unsubscribeNewsletter(email){
    return this.http.get(this.url+'subscription/un-subscribe-user/'+email);
  }

  copyAddress(params){
    return this.http.post(this.url+'user/shipping-billing-address/copy-address', params);
  }

  doProcessOrderWithAmazonPay(params){
    return this.http.post(this.url+'user/amazon-pay/do-process-order', params);
  }

  moveToWishList(params){
    return this.http.post(this.url+'user/move-to-wish-list', params);
  }

  getCMSData(parameters){
    return this.http.post(this.url+'master/cms/get-cms-data', parameters);
  }

  //add product to local cart before login
  addProductToLocalCart(id){
    var cartList=[]
    var localStorageUserCartlist=JSON.parse(localStorage.getItem('localUserCartlist'))
    if((localStorageUserCartlist==null)||(localStorageUserCartlist.length==0)){
      cartList=[id]
      localStorage.setItem('localUserCartlist',JSON.stringify(cartList))
    }else{
      cartList=localStorageUserCartlist
      var increment=0
      cartList.map(data=>{
        if(data==id){
          increment++
        }
      })
      if(increment==0){
        let tempArray=[]
        tempArray=cartList
        tempArray.push(id)
        for(var i=0; i<tempArray.length; i++){
          for(var j=i+1; j<tempArray.length; j++){
            if(tempArray[i]<tempArray[j]){
              let temp=tempArray[i]
              tempArray[i]=tempArray[j]
              tempArray[j]=temp
            }
          }
        }
        cartList=tempArray
      }
      localStorage.setItem('localUserCartlist',JSON.stringify(cartList))
    }
    return true
  }
}
