import {
    NgModule
} from '@angular/core';
import {
    CommonModule
} from '@angular/common';
import {
    UserRoutingModule
} from './user-routing.module';
import {
    HomeComponent
} from './home/home.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AboutUsComponent } from './about-us/about-us.component';
import { ProfileComponent } from './profile/profile.component';
import { MiniHeaderBottomComponent } from '../../core/user/header/mini-header-bottom/mini-header-bottom.component';
import { ShippingBillingComponent } from './shipping-billing/shipping-billing.component';
import {DropdownModule} from 'primeng/dropdown';
import { SearchProductComponent } from './search-product/search-product.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { SearchCategoryProductComponent } from './search-category-product/search-category-product.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmationService} from 'primeng/api';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CustomizationComponent } from './customization/customization.component';
import { PaypalComponent } from './payment-gateway/paypal/paypal.component';
import { UserOrderComponent } from './user-order/user-order.component';
import {InputMaskModule} from 'primeng/inputmask';
import { ConfigurationComponent } from './configuration/configuration.component';
import { ConfigurationDetailComponent } from './configuration-detail/configuration-detail.component';
import { UserOrderDetailComponent } from './user-order-detail/user-order-detail.component';
import {DataTableModule} from "angular-6-datatable";
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { BlogComponent } from './blog/blog.component';
import { FaqComponent } from './faq/faq.component';
// import { SafePipe } from './safe.pipe';
import { ProfileSidebarComponent } from './profile-sidebar/profile-sidebar.component';
import {RatingModule} from 'primeng/rating';
import { TempdataComponent } from './tempdata/tempdata.component';
import { ShareModule } from '@ngx-share-pat/core';
import { ShareButtonsModule } from '@ngx-share/buttons';
import { library } from '@fortawesome/fontawesome-svg-core';
import { faFacebookSquare } from '@fortawesome/free-brands-svg-icons/faFacebookSquare';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { MiniHeaderTopComponent } from '../../core/user/header/mini-header-top/mini-header-top.component';
import { AmazonPayComponent } from './checkout/amazon-pay/amazon-pay.component';
import { UnsubscribeNewsLetterComponent } from './unsubscribe-news-letter/unsubscribe-news-letter.component';
import { CoreModule } from '../../core/core.module';
import {PaginatorModule} from 'primeng/paginator';

const icons = [
    // ... other icons
    faFacebookSquare
  ];

  library.add(...icons);

const shareProp = {
  facebook: {
    icon: ['fab', 'facebook-square']
  }
};
@NgModule({
    imports: [
        CommonModule,
        UserRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        DropdownModule,
        ConfirmDialogModule,
        NgbModule,
        InputMaskModule,
        DataTableModule,
        Ng2SearchPipeModule,
        RatingModule,
        ShareModule.forRoot(),
        ShareButtonsModule.forRoot({ prop: shareProp }),
        CoreModule,
        PaginatorModule
    ],
    declarations: [
        HomeComponent,
        AboutUsComponent,
        ProfileComponent,
        MiniHeaderBottomComponent,
        ShippingBillingComponent,
        SearchProductComponent,
        ProductDetailsComponent,
        SearchCategoryProductComponent,
        WishlistComponent,
        ShoppingCartComponent,
        CheckoutComponent,
        CustomizationComponent,
        PaypalComponent,
        UserOrderComponent,
        ConfigurationComponent,
        ConfigurationDetailComponent,
        UserOrderDetailComponent,
        ContactUsComponent,
        BlogComponent,
        FaqComponent,
        // SafePipe,
        ProfileSidebarComponent,
        TempdataComponent,
        ResetPasswordComponent,
        MiniHeaderTopComponent,
        AmazonPayComponent,
        UnsubscribeNewsLetterComponent,
    ],
    bootstrap: [],
    providers:[ConfirmationService],
})
export class UserModule {}