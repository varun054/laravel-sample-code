import { Router } from '@angular/router';
import {AppService} from './../../../app.service';
import {ConfirmationService} from 'primeng/api';
import {ToastrService} from 'ngx-toastr';
import {environment} from './../../../../environments/environment';
import {Component,OnInit} from '@angular/core';
import {UserService} from '../user.service';
import {Location} from '@angular/common';
import {ViewChild,ElementRef} from '@angular/core';

declare var $: any;

@Component({
    selector: 'app-shopping-cart',
    templateUrl: './shopping-cart.component.html',
    styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {

    constructor(
        private userService: UserService, 
        private toastr: ToastrService, 
        private confirmationService: ConfirmationService, 
        private appService: AppService, 
        private location: Location, 
        private router:Router
    ) {
        $('#scroll_top').click();
    }

    userData: any
    userId: any
    cartData: any = []
    loader: boolean = false
    imagePath: any
    totalAmount: number
    quantityArray: any = []
    cartAmount: any;
    cartListCount: any
    minSize: number = 1
    maxSize: number = 10
    localCartList: any = []
    localCartListData: any = []
    localCartLength: any
    removeLocalCartDataId: any
    billingData:any
    shippingData:any
    @ViewChild('closeModal') closeModal: ElementRef;
    @ViewChild('remove_modal_open') remove_modal_open: ElementRef;
    @ViewChild('remove_modal_close') remove_modal_close: ElementRef;
    local_cart_data : any;
    local_cart_data_length = 0;
    public display_title : string;

    ngOnInit() {
        this.userData = JSON.parse(localStorage.getItem('userData'))
        if (this.userData != null) {
            this.userId = this.userData['id']
            this.getShoppingCartData(this.userId)
        } else {
            this.getLocalShoppingCartData();
        }
    }

    productDetails(data)
    {
        let display_title = '';

        if (data.products)
        {
            display_title = data.products.display_title.split(' ').join('-');
        } else {
            display_title = data.product_desc.display_title.split(' ').join('-');
        }

        this.display_title = display_title.split('/').join('-');

        if (this.display_title)
        {
            return true;
        } else {
            return false;
        }
    }

    getLocalShoppingCartData()
    {
        this.local_cart_data = JSON.parse(localStorage.getItem('localUserCartlist'));

        if(this.local_cart_data)
        {
            this.local_cart_data_length = this.local_cart_data.length;

            this.appService.setCartListCount(this.local_cart_data.length);
            
            let count : any = 0.00;

            this.local_cart_data.map(data => {
                if (data.kit_id) {
                    count = parseFloat(count) + parseFloat(data.kit_price);
                } else {
                    count = parseFloat(count) + parseFloat(data.product_desc.price);
                }
            });

            this.cartAmount = count.toFixed(2);

            this.userService.getLocalCartData().subscribe(result => {
                if (result['status'] == 'success')
                {
                    this.imagePath = result['path'];

                    
                } else {
                    this.toastr.error(result['message']);
                }
            }, (error) => {
                this.appService.unAuthorizedUserAccess(error, 'front');
            });
        }
    }

    getShoppingCartData(userId) {
        this.loader = true
        this.userService.getShoppingCartData(userId).subscribe(result => {
            if (result['status'] == 'success') {
                this.cartData = result['data']
                this.cartListCount = result['count']
                this.appService.setCartListCount(this.cartListCount)
                this.imagePath = result['path']
                if (this.cartData.length > 0) {
                    var temp = 0
                    this.cartData.map(data => {
                        temp = temp + data.products.price
                    })
                    this.totalAmount = temp
                } else {
                    this.totalAmount = 0
                }
            } else {
                this.toastr.error(result['message'])
            }
            this.loader = false
            var amount : any = 0;
            this.cartData.map(data => {
                let no_of_items = data.number_of_items
                let price = data.products.price
                let tempObject = {
                    'number_of_items': no_of_items,
                    'price': price
                }
                this.quantityArray.push(tempObject);

                if(data.products.is_active==1){
                    let kit_configuration_additional_price = 0;

                    if (data.kit_id) {
                        amount = amount + ((data.number_of_items) * (parseFloat(data.kit_price)))
                    }else{
                        amount = amount + ((data.number_of_items) * (parseFloat(data.products.price)));
                    }
                }
                
                this.cartAmount = parseFloat(amount).toFixed(2);
            })
        },
        (error) => {
            this.loader = false
            this.appService.unAuthorizedUserAccess(error, 'front');
        })
    }

    removeItemFromCartList(id) {
        this.confirmationService.confirm({
            message: 'Are you sure that you want to remove this product from your Cart?',
            accept: () => {
                this.loader = true
                this.userService.removeItemFromCart(id)
                    .subscribe(result => {
                            if (result['status'] == 'success') {
                                this.toastr.success(result['message'])
                                this.getShoppingCartData(this.userId)
                            } else {
                                this.toastr.error(result['message'])
                            }
                            this.loader = false
                        },
                        (error) => {
                            this.appService.unAuthorizedUserAccess(error, 'front');
                            // this.toastr.error(error.message)
                            this.loader = false
                        })
            }
        });
    }

    removeItemFromLocalCartList() {
        var id = this.removeLocalCartDataId

        this.local_cart_data.splice(this.removeLocalCartDataId, 1);

        localStorage.setItem('localUserCartlist', JSON.stringify(this.local_cart_data));

        this.getLocalShoppingCartData();

        this.remove_modal_close.nativeElement.click();
    }

    confirmRemove(index) {
        this.removeLocalCartDataId = index
        this.remove_modal_open.nativeElement.click();
    }

    getNewQuantity(event, i) {
        if (!isNaN(event.srcElement.value) && event.srcElement.value) {
            var j = 0;
            var amount = 0;
            this.quantityArray.map(data => {
                if (j == i) {
                    data.number_of_items = parseInt(event.srcElement.value)

                }
                amount = amount + ((data.number_of_items) * (data.price))
                j++
            })
            this.cartAmount = amount
            this.loader = true
            this.userService.saveUpdatedCartData(this.cartData)
                .subscribe(result => {
                        if (result['status'] == 'success') {

                        } else {
                            this.toastr.error(result['message'])
                        }
                        this.loader = false
                    },
                    (error) => {
                        this.appService.unAuthorizedUserAccess(error, 'front')
                        this.loader = false
                    })
        }
    }

    minusQuantity(i) {
        var myArray = []
        if (this.cartData[i].number_of_items > this.minSize) {
            this.loader = true

            myArray = this.cartData
            for (var j = 0; j < myArray.length; j++) {
                if (i == j) {
                    myArray[j].number_of_items--
                }
            }
            this.cartData = myArray
            this.userService.saveUpdatedCartData(this.cartData)
                .subscribe(result => {
                        if (result['status'] == 'success') {
                            this.getShoppingCartData(this.userId)
                        } else {
                            this.toastr.error(result['message'])
                        }
                        this.loader = false
                    },
                    (error) => {
                        this.appService.unAuthorizedUserAccess(error, 'front')
                        this.loader = false
                    })
        }
    }

    plusQuantity(i) {
        var myArray = []

        if (this.cartData[i].number_of_items < this.maxSize) {
            this.loader = true
            myArray = this.cartData
            for (var j = 0; j < myArray.length; j++) {
                if (i == j) {
                    myArray[j].number_of_items++
                }
            }
            this.cartData = myArray
            this.userService.saveUpdatedCartData(this.cartData)
                .subscribe(result => {
                        if (result['status'] == 'success') {
                            this.getShoppingCartData(this.userId)
                        } else {
                            this.toastr.error(result['message'])
                        }
                        this.loader = false
                    },
                    (error) => {
                        this.appService.unAuthorizedUserAccess(error, 'front')
                        this.loader = false
                    })
        }
    }

    cannotCheckOutLoginFirst() {
        this.toastr.warning('Please login first!')
        $('#user_login').modal('show');
    }

    moveToWishlist(param)
    {
        if (!this.userId)
        {
            this.toastr.warning('Please login first');
            $('#user_login').modal('show');
            return;
        }

        if (this.userData.role_id != 2)
        {
            this.toastr.warning('Please login with user account.');
            return;
        }

        this.loader = true;

        let dataObject = {
            id : param.id,
            user_id: this.userData['id'],
            product_id: param.product_id,
            number_of_items: 1,
            kit_id : param.kit_id,
            kit_price : param.kit_price,
            kit_desc : param.kit_desc,
        }

        this.userService.moveToWishList(dataObject).subscribe(result => {
            if (result['status'] == 'success') {
                this.toastr.success(result['message'])
                this.loader = false;
                this.getWishListCount();
                this.getCartListCount();
                this.getShoppingCartData(this.userId)
            } else {
                this.toastr.error(result['message'])
                this.loader = false;
            }
        },
        (error) => {
            this.appService.unAuthorizedUserAccess(error, 'front');
            // this.toastr.error(error.message)
            this.loader = false;
        })
    }

    getWishListCount() {
        this.userService.wishListCount(this.userId)
            .subscribe(result => {
                    if (result['status'] == 'success') {
                        this.appService.setWishListCount(result['count']);
                    } else {
                        this.toastr.error(result['message'])
                    }
                },
                (error) => {
                    this.appService.unAuthorizedUserAccess(error, 'front');
                    // this.toastr.error(error.message)
                })
    }

    getCartListCount() {
        this.userService.cartListCount(this.userId).subscribe(result => {
            if (result['status'] == 'success') {
                this.appService.setCartListCount(result['count'])
            } else {
                this.toastr.error(result['message'])
            }
        }, (error) => {
            this.appService.unAuthorizedUserAccess(error, 'front');
            // this.toastr.error(error.message)
        });
    }
}