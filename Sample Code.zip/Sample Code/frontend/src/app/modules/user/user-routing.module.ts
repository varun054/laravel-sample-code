import { BlogComponent } from './blog/blog.component';
import { FaqComponent } from './faq/faq.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { ShippingBillingComponent } from './shipping-billing/shipping-billing.component';
import { SearchProductComponent } from './search-product/search-product.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ProfileComponent } from './profile/profile.component';
import { UserGuard } from '../../guards/user.guard';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { PaypalComponent } from './payment-gateway/paypal/paypal.component';
import { CustomizationComponent } from './customization/customization.component';
import { UserOrderComponent } from './user-order/user-order.component';
import { ConfigurationComponent } from './configuration/configuration.component';
import { ConfigurationDetailComponent } from './configuration-detail/configuration-detail.component';
import { UserOrderDetailComponent } from './user-order-detail/user-order-detail.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { ProfileSidebarComponent } from './profile-sidebar/profile-sidebar.component';
import { TempdataComponent } from './tempdata/tempdata.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { AmazonPayComponent } from './checkout/amazon-pay/amazon-pay.component';
import { UnsubscribeNewsLetterComponent } from './unsubscribe-news-letter/unsubscribe-news-letter.component';

const routes: Routes = [
  {
    path:'',
    component:HomeComponent,
  },
  {
    path:'about-us',
    component:AboutUsComponent,
  },
  {
    path:'contact-us',
    component:ContactUsComponent,
  },
  {
    path:'FAQ',
    component:FaqComponent
  },
  {
    path:'blog',
    component:BlogComponent
  },
  {
    path:'sidebar',
    component:ProfileSidebarComponent
  },
  {
    path:'user-profile',
    component:ProfileComponent,
    canActivate:[UserGuard]
  },
  {
    path:'my-orders',
    component:UserOrderComponent,
    canActivate:[UserGuard]
  },
  {
    path:'my-orders/:id',
    component:UserOrderDetailComponent,
    canActivate:[UserGuard]
  },
  {
    path:'my-configuration',
    component:ConfigurationComponent,
    canActivate:[UserGuard]
  },
  {
    path:'my-configuration/:id',
    component:ConfigurationDetailComponent,
    canActivate:[UserGuard]
  },
  {
    path:'shipping-billing',
    component:ShippingBillingComponent,
    canActivate:[UserGuard]
  },
  {
    path:'search-product',
    component:SearchProductComponent,
  },
  {
    path:'search-product/:brand_id',
    component:SearchProductComponent,
  },
  {
    path:'search-product/:brand_id/:category_id',
    component:SearchProductComponent,
  },
  {
    path:'search-product/:brand_id/:category_id/:search_text',
    component:SearchProductComponent,
  },
  {
    path:'product-details/:id/:display_title',
    component:ProductDetailsComponent,
  },
  {
    path:'wishlist',
    component:WishlistComponent,
    canActivate:[UserGuard]
  },
  {
    path:'shopping-cart',
    component:ShoppingCartComponent,
    // canActivate:[UserGuard]
  },
  {
    path:'checkout',
    component:CheckoutComponent,
    canActivate:[UserGuard]
  },
  {
    path:'paypal/checkout',
    component:PaypalComponent,
    canActivate:[UserGuard]
  },
  {
    path:'checkout/amazon-pay',
    component:AmazonPayComponent,
    canActivate:[UserGuard]
  },
  {
    path:'customization/:id/:product_title',
    component:CustomizationComponent,
  },
  {
    path:'temp',
    component:TempdataComponent
  },{
    path:'reset-password/:token',
    component:ResetPasswordComponent
  },{
    path:'unsubscibe/:email',
    component:UnsubscribeNewsLetterComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
