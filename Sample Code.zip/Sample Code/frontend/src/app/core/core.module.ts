import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { BoxModule, TabsModule, DropdownModule } from 'angular-admin-lte';

import { HeaderInnerComponent } from './admin/header-inner/header-inner.component';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmationService} from 'primeng/api';
import { SafePipe } from '../modules/user/safe.pipe';
import { RecaptchaModule } from 'ng-recaptcha';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    HttpModule,
    DropdownModule,
    TabsModule,
    BoxModule,
    ConfirmDialogModule,
  ],
  declarations: [HeaderInnerComponent, SafePipe, /*RecaptchaModule*/],
  exports: [BoxModule, TabsModule, HeaderInnerComponent, SafePipe, RecaptchaModule],
  providers:[ConfirmationService],
})
export class CoreModule { }
