import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonAuthService {
  url=environment.url
  constructor(private http:HttpClient, private router:Router) { }

  authenticate(value) {
  return this.http.post(this.url + 'auth/do-authenticate-user', value)
  }

  changePassword(value){
    return this.http.post(this.url+'password/change-password',value);
  }

  changePasswordByAdmin(params)
  {
    return this.http.post(this.url+'password/change-password-by-admin',params);
  }

  forgetPassword(value) {
    return this.http.post(this.url + 'password/forgot-password', value);
  }

  updateUserData(value){
    return this.http.post(this.url+'admin/user-manage/update-profile',value)
  }

  doUpdateProfiePicture(value){
    return this.http.post(this.url+'admin/user-manage/do-update-profile-picture',value);
  }

  registration(value){
    return this.http.post(this.url+'auth/do-register-user',value);
  }

  getUserDetails(id){
    return this.http.get(this.url+'admin/user-manage/get-profile-data/'+id)
  }
}
