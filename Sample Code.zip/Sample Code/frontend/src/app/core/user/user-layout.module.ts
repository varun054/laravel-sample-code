import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import {
    NgModule
} from '@angular/core';
import {
    CommonModule
} from '@angular/common';
import {
    UserLayoutRoutingModule
} from './user-layout-routing.module';
import {
    UserLayoutComponent
} from './user-layout.component';
import {
    TopHeaderComponent
} from './header/top-header/top-header.component';
import { MainHeaderComponent } from './header/main-header/main-header.component';
import { FooterComponent } from './footer/footer.component';
// import { MiniHeaderBottomComponent } from './header/mini-header-bottom/mini-header-bottom.component';
import { SocialLoginModule, AuthServiceConfig } from "angularx-social-login";
import { GoogleLoginProvider, FacebookLoginProvider, LinkedInLoginProvider} from "angularx-social-login";
// import { RecaptchaModule } from 'ng-recaptcha';
import {DropdownModule} from 'primeng/dropdown';
import { CoreModule } from '../core.module';

let config = new AuthServiceConfig([
    {
      id: GoogleLoginProvider.PROVIDER_ID,
      provider: new GoogleLoginProvider("822248891583-v3vkvhbn56vtvcrla911ksh5eeeitv88.apps.googleusercontent.com")
    },
    {
      id: FacebookLoginProvider.PROVIDER_ID,
      provider: new FacebookLoginProvider("285242738856134")
    },
  ]);

export function provideConfig() {
    return config;
}

@NgModule({
    imports: [
        CommonModule,
        UserLayoutRoutingModule,
        ReactiveFormsModule,
        FormsModule,
        SocialLoginModule,
        // RecaptchaModule,
        DropdownModule,
        CoreModule,
    ],
    declarations: [
        UserLayoutComponent,
        TopHeaderComponent,
        MainHeaderComponent,
        FooterComponent,
    ],
    providers: [
        {
          provide: AuthServiceConfig,
          useFactory: provideConfig
        }
      ],
    bootstrap: []
})
export class UserLayoutModule {}