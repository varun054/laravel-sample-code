import { CoreService } from './../../../services/core.service';
import { AdminService } from './../../../../modules/admin/admin.service';
import { ValidatorList } from '../../../../shared/validator.service';
import { AuthenticationService } from '../../../../modules/admin/authentication/authentication.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import {
    Component,
    OnInit
} from '@angular/core';
import { Router } from '@angular/router';
import { CommonAuthService } from '../../../common-auth/common-auth.service';
import {
    ToastrService
} from 'ngx-toastr';
import {
    environment
} from '../../../../../environments/environment';
import { AppService } from '../../../../app.service';
import { ViewChild, ElementRef} from '@angular/core';
import { UserService } from '../../../../modules/user/user.service';

import { AuthService } from "angularx-social-login";
import { FacebookLoginProvider, GoogleLoginProvider, LinkedInLoginProvider } from "angularx-social-login";
import { SelectItem} from 'primeng/api';
declare var $: any;
interface CountryCode{
	phonecode:number,
	id:number
  }
@Component({
    selector: 'app-main-header',
    templateUrl: './main-header.component.html',
    styleUrls: ['./main-header.component.css']
})
export class MainHeaderComponent implements OnInit {

	recaptcha_site_key;
	loginForm:FormGroup
	registerUser:FormGroup
	forgetPasswordForm:FormGroup
	changePasswordForm: FormGroup;
	userName:any
	passwordMismatch:boolean=false
	public l_r_tab : string = 'login';
	SuccessMessage:any
	loginReg:boolean=true
	forgetPassword:boolean=false
	phone_code_list:any
	public account_validation_messages=ValidatorList.account_validation_messages
	wishListCount:any
	cartListCount:any
	public userData : any
	socialiteLoggedIn:boolean=false
	socialiteData:any=null
	loader:boolean=false
	countryCode:SelectItem[]
	selectedCountryCode:CountryCode;

	public loginBtn : boolean = false;

	@ViewChild('closeModal') closeModal: ElementRef;
	@ViewChild('login') login: ElementRef;

	@ViewChild('logout_modal_open') logout_modal_open: ElementRef;

	@ViewChild('logout_modal_close') logout_modal_close: ElementRef;

	@ViewChild('change_pwd_modal_close') change_pwd_modal_close: ElementRef;

	public registrationBtn : boolean = false;

	public forgotBtn : boolean = false;

	public passwordNotMatchingFlag : boolean = false;

	public changePasswordFormSubmitted : boolean = false;

	public changePasswordBtn : boolean = false;

	public mega_menu_data;

	constructor(
		private formBuilder:FormBuilder,
		private router:Router,
		private authenticationService:AuthenticationService,
		private commonAuthService:CommonAuthService,
		private toastr: ToastrService,
		private adminService:AdminService,
		private coreService:CoreService,
		private appService:AppService,
		private userService:UserService,
		private authService: AuthService
	) {
		this.userData = JSON.parse(localStorage.getItem('userData'));

		this.recaptcha_site_key = environment.recaptcha_site_key;
	}

	async signInWithGoogle(){
		// this.socialiteData=null
		await this.authService.signIn(GoogleLoginProvider.PROVIDER_ID);
		this.socialite(this.socialiteData)
	}

	async signInWithFB() {	
		await this.authService.signIn(FacebookLoginProvider.PROVIDER_ID)
		this.socialite(this.socialiteData)
	}

	signOut(): void {
		if(this.socialiteLoggedIn==true){
			this.authService.signOut();
			this.socialiteLoggedIn=false
			localStorage.removeItem('userData')
		}
	}

	resolved(captchaResponse: string)
	{
		this.registerUser.patchValue({
			recaptcha:1
		})
    }

	

	socialite(data){
		if(data!=null){
			if(data.provider=='FACEBOOK'){
				this.loader=true
				this.userService.facebookLogin(data).subscribe(result=>{
					if(result['status']=='success'){
						if(result['data'].role_id==2){
							this.userData=result['data']

							this.loginBtn = false;
	
							this.closeModal.nativeElement.click();
	
							this.toastr.success('Facebook Logged in successfully');
	
							let authData = result['data'];
	
							authData.last_access_time = new Date().getTime();
	
							localStorage.setItem('userData',JSON.stringify(authData));
	
							localStorage.setItem('token',JSON.stringify(result['authorization_token']));
	
							environment.userData = JSON.parse(localStorage.getItem('userData'));
	
							this.appService.setUserData(environment.userData);

							let local_cart = JSON.parse(localStorage.getItem('localUserCartlist'));

							if(local_cart && local_cart.length > 0)
							{
								this.addLocalProductToCart(authData);
							}else{
								if (authData.carts.length > 0)
								{
									this.router.navigate(['checkout']);
								}else{
									this.router.navigate(['user-profile']);
								}
							}
	
							this.loginForm.reset()
						}else{
							this.loginBtn = false;
							this.toastr.error('Invalid Username or Password.');
						}
						this.loader=false
					}
					else{
						this.loginBtn = false;
						this.toastr.error(result['message'])
						this.loader=false
					}
				}
				,(error)=>{
					this.toastr.error(error.message)
					this.loader=false
				})
			}

			if(this.socialiteData.provider=='GOOGLE'){
				this.loader=true
				this.userService.googleLogin(data)
				.subscribe(result=>{
					if(result['status']=='success'){
						if(result['data'].role_id==2){
							this.userData=result['data']

							this.loginBtn = false;
	
							this.closeModal.nativeElement.click();
	
							this.toastr.success('Google Logged in successfully');
	
							let authData = result['data'];
	
							authData.last_access_time = new Date().getTime();
	
							localStorage.setItem('userData',JSON.stringify(authData));
	
							localStorage.setItem('token',JSON.stringify(result['authorization_token']));
	
							environment.userData = JSON.parse(localStorage.getItem('userData'));
	
							this.appService.setUserData(environment.userData);
							
							let local_cart = JSON.parse(localStorage.getItem('localUserCartlist'));

							if(local_cart && local_cart.length > 0)
							{
								this.addLocalProductToCart(authData);
							}else{
								if (authData.carts.length > 0)
								{
									this.router.navigate(['checkout']);
								}else{
									this.router.navigate(['user-profile']);
								}
							}

							this.loginForm.reset()
						}else{
							this.loginBtn = false;
							this.toastr.error('Invalid Username or Password.');
						}
						this.loader=false
					}
					else{
						this.toastr.error(result['message'])
						this.loader=false
					}
				}
				,(error)=>{
					this.toastr.error(error.message)
					this.loader=false
				})
			}
		}
		
	}

    ngOnInit() {

		this.authService.authState.subscribe((user) => {
			this.socialiteData = user;
			this.socialiteLoggedIn = (user != null);
		});

		if(localStorage.getItem('userData')==null){
			this.socialiteData=null
		}
		
    	this.appService.getUserData().subscribe((result)=>{
			this.userData = result;
        });

    	this.appService.openPopUp().subscribe((result)=>{
			this.login.nativeElement.click();
        });

		this.getPhoneCodes();

		this.loginForm=this.formBuilder.group({
			email:['',[Validators.required, ValidatorList.emailValidator]],
			password:['',[Validators.required]],
			
		})
		this.loginForm.reset()

		this.registerUser=this.formBuilder.group({
			first_name:['',[Validators.required, ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
			last_name:['',[Validators.required, ValidatorList.numberNotRequiredValidator, ValidatorList.avoidEmptyStrigs]],
			country_code:['',[Validators.required]],
			mobile_no:['',[Validators.required,Validators.minLength(7),Validators.maxLength(15),Validators.pattern('^[0-9-+()]*$')]],
			email:['',[Validators.required, ValidatorList.emailValidator]],
			password:['',[Validators.required,Validators.minLength(6),Validators.pattern('^(?=.*[0-9])(?=.*[a-zA-Z])[a-zA-Z0-9!@#$%^&*]{6,}$')]],
			password_confirmation:['',[Validators.required,Validators.pattern('^(?=.*[0-9])(?=.*[a-zA-Z])[a-zA-Z0-9!@#$%^&*]{6,}$')]],
			recaptcha: ['', Validators.required]
		})

		this.forgetPasswordForm=this.formBuilder.group({
			email:['',[Validators.required, Validators.email]]	
		})

		this.createChangePasswordForm();

		this.appService.getWishListCount().subscribe(result=>{
			this.wishListCount=result
		})

		this.appService.getCartListCount().subscribe(result=>{
			this.cartListCount=result
		})

		if(this.userData!=null){
			
			this.coreService.getwishListCount(this.userData['id']).subscribe(result=>{
				if(result['status']=='success'){
					this.wishListCount=result['count']
				}
				else{
					this.toastr.error(result['message'])
				}
			},(error)=>{
				// this.toastr.error(error.message)
				this.appService.unAuthorizedUserAccess(error, 'front');
			});
			

			this.coreService.getCategoryListCount(this.userData['id'])
			.subscribe(result=>{
			if(result['status']=='success'){
				this.cartListCount=result['count']
			}
			else{
				this.toastr.error(result['message'])
			}
			},
			(error)=>{
				// this.toastr.error(error.message)
				this.appService.unAuthorizedUserAccess(error, 'front');
			})
		}
		else{
			this.wishListCount=0
			this.cartListCount=0
		}

		this.getMegaMenuData();

		this.countryCode = [
			{label: 'Select Country Code', value: null},
		];
	}

	getMegaMenuData() {
		try{
			localStorage.removeItem('laptop');
			localStorage.removeItem('desktop');
			localStorage.removeItem('accessories');
			localStorage.removeItem('extended_warranty');
			localStorage.removeItem('software');
			
            this.coreService.getMegaMenuData(null).subscribe(res => {
                if (res['status'] == 'success') {
                    this.mega_menu_data = res['data'];

                    if (this.mega_menu_data.length > 0) {
                    	this.storeSubcategoryData(this.mega_menu_data);
                    }
                } else {
                    this.toastr.error(res['message']);
                }
            }, error => {
                this.toastr.error(error.message);
            });
        }catch(err){
            this.toastr.error(err);
        }
	}

	storeSubcategoryData(data){
		for (var i = 0; i < data.length; i++) {
			if(data[i].id == 8) {
    			localStorage.setItem('laptop',JSON.stringify(data[i].children_front));
    		}else if(data[i].id == 9) {
    			localStorage.setItem('desktop',JSON.stringify(data[i].children_front));
    		}else if(data[i].id == 10) {
    			localStorage.setItem('accessories',JSON.stringify(data[i].children_front));
    		}else if(data[i].id == 11) {
    			localStorage.setItem('extended_warranty',JSON.stringify(data[i].children_front));
    		}else if(data[i].id == 12) {
    			localStorage.setItem('software',JSON.stringify(data[i].children_front));
    		}

			this.storeSubcategoryData(data[i].children_front);
    	}
	}

	createChangePasswordForm() {
		this.changePasswordForm = new FormGroup({
            'old_password' : new FormControl('', [Validators.required,Validators.minLength(6),Validators.pattern('^(?=.*[0-9])(?=.*[a-zA-Z])[a-zA-Z0-9!@#$%^&*]{6,}$')]),
            'password' : new FormControl('', [Validators.required,Validators.minLength(6),Validators.pattern('^(?=.*[0-9])(?=.*[a-zA-Z])[a-zA-Z0-9!@#$%^&*]{6,}$')]),
            'password_confirmation' : new FormControl('', [Validators.required,Validators.minLength(6),Validators.pattern('^(?=.*[0-9])(?=.*[a-zA-Z])[a-zA-Z0-9!@#$%^&*]{6,}$')])
        });
	}

	public getPhoneCodes () {
        try{
            this.coreService.getPhoneCodes().subscribe(res => {
                if (res['status'] == 'success') {
					this.phone_code_list = res['data'];
					this.phone_code_list.forEach(data=>{
						this.countryCode.push({
						  label:('+'+data.phonecode+'('+data.iso+')'),value:data.id
						})
					  })
                } else {
                    this.toastr.error(res['message']);
                }
            }, error => {
                this.toastr.error(error.message);
            });
        }catch(err){
            this.toastr.error(err);
        }
	}
	
	loginValidateAllFormFields(formGroup: FormGroup) {
		Object.keys(this.loginForm.controls).forEach(field => {
			const control = this.loginForm.get(field);
			control.markAsTouched({ onlySelf: true });
			control.markAsDirty({ onlySelf: true });
		});
	  }
	

	onLoginSubmit(value){
		if(this.loginForm.invalid){
			this.loginValidateAllFormFields(this.loginForm)
			return
		}else{
			this.loader = true;

			this.authenticationService.userLogin(this.loginForm.value).subscribe(result=>{
				if(result['status']=='success'){
					if(result['auth_data'].role_id==2){
						
						this.loader = false;

						this.closeModal.nativeElement.click();

						this.toastr.success('Logged in successfully');

						let authData = result['auth_data'];

        				authData.last_access_time = new Date().getTime();

						localStorage.setItem('userData',JSON.stringify(authData));

						localStorage.setItem('token',JSON.stringify(result['authorization_token']));

						environment.userData = JSON.parse(localStorage.getItem('userData'));

						this.appService.setUserData(environment.userData);

						let local_cart = JSON.parse(localStorage.getItem('localUserCartlist'));

						if(local_cart && local_cart.length > 0)
						{
							this.addLocalProductToCart(authData);
						}else{
							if (authData.carts.length > 0)
							{
								this.router.navigate(['checkout']);
							}else{
								this.router.navigate(['user-profile']);
							}
						}

						this.loginForm.reset()
					}else{
						this.loader = false;
						this.toastr.error('Invalid Username or Password.');
					}
				}else{
					this.loader = false;
					this.toastr.error(result['message']);
				}
			}, error => {
				this.loader = false;
				this.toastr.error(error);
			});
		}
		
	}

	addLocalProductToCart(authData)
	{
		let local_cart_data = JSON.parse(localStorage.getItem('localUserCartlist'))
		
		let dataObject={
			productCartArray : local_cart_data,
			user_id:authData.id,
		}
		this.userService.addProductCartArray(dataObject).subscribe(result=>{
			if(result['status']=='success'){
				localStorage.removeItem('localUserCartlist');
				this.router.navigate(['checkout']);
			}
			else
				this.toastr.error(result['message'])
		}, (error)=>{
			this.toastr.error(error.message)
		});
	}

	addLocalProductToCart_old(authData){
		var cartList=[]
		// var wishList=[]
		// var localStorageUserWishlist=JSON.parse(localStorage.getItem('localUserWishlist'))
		var localStorageUserCartlist=JSON.parse(localStorage.getItem('localUserCartlist'))
		
		if((localStorageUserCartlist!=null) && (localStorageUserCartlist.length>0)){
			cartList=localStorageUserCartlist
			
			let dataObject={
				productCartArray:cartList,
				user_id:authData.id,
				number_of_items:1
			}
			this.userService.addProductCartArray(dataObject)
			.subscribe(result=>{
				if(result['status']=='success'){
					localStorage.removeItem('localUserCartlist')
				}
				else{
					this.toastr.error(result['message'])
				}
			},
			(error)=>{
				this.toastr.error(error.message)
			})
		}
	}

	signIn(){
		this.l_r_tab = 'login';
		this.loginReg=true
		this.forgetPassword=false
	}

	resetForm(){
		this.loginForm.reset();
		this.registerUser.reset();
		this.forgetPasswordForm.reset();
		this.closeModal.nativeElement.click();
		this.loginReg = true;
		this.l_r_tab = 'login';
	}

	clearMismatchError(){
		this.passwordMismatch=false
	}

	registerValidateAllFormFields(formGroup: FormGroup) {
		Object.keys(this.registerUser.controls).forEach(field => {
			const control = this.registerUser.get(field);
			control.markAsTouched({ onlySelf: true });
			control.markAsDirty({ onlySelf: true });
		});
	  }

	onRegistrationSubmit(value){
		this.passwordMismatch=false
		if(this.registerUser.value.password_confirmation!==this.registerUser.value.password){
			this.passwordMismatch=true
			return
		}

		if(this.registerUser.valid){

			this.loader = true;

			this.commonAuthService.registration(value).subscribe((result)=>{
				if(result['status']=='success'){
					this.loader = false;

					this.closeModal.nativeElement.click();

					this.toastr.success(result['message'])

					let authData = result['auth_data'];

    				authData.last_access_time = new Date().getTime();

					localStorage.setItem('userData',JSON.stringify(authData));

					localStorage.setItem('token',JSON.stringify(result['authorization_token']));

					environment.userData = JSON.parse(localStorage.getItem('userData'));

					this.appService.setUserData(environment.userData);

					let local_cart = JSON.parse(localStorage.getItem('localUserCartlist'));
						
					if(local_cart && local_cart.length > 0)
					{
						this.addLocalProductToCart(authData);
					}else{
						this.router.navigate(['user-profile']);
					}

					/*this.addLocalProductToCart(result['auth_data'])

					this.router.navigate(['user-profile']);*/

					this.userName = result['auth_data'].name;

					this.registerUser.reset();					
				}
				else{
					this.loader = false;
					this.toastr.error(result['message'])
				}
			},
			(error)=>{
				this.loader = false;
				this.toastr.error(error)
			});
		} else{
			this.registerValidateAllFormFields(this.registerUser)
			return
		}
	}

	forgetValidateAllFormFields(formGroup: FormGroup) {
		Object.keys(this.forgetPasswordForm.controls).forEach(field => {
			const control = this.forgetPasswordForm.get(field);
			control.markAsTouched({ onlySelf: true });
			control.markAsDirty({ onlySelf: true });
		});
	  }

	onForgetPasswordFormSubmit(formData){
		if(this.forgetPasswordForm.invalid){
			this.forgetValidateAllFormFields(this.forgetPasswordForm)
			return
		}

		this.loader = true;

		this.adminService.forgetPassword(formData).subscribe((result)=>{
			if(result['status']=='success'){
				this.loader = false;

				this.toastr.success(result['message']);

				this.resetForm();
			}
			else{
				this.loader = false;
				this.toastr.error(result['message'])
			}
		});
	}

    doSwitchL_R(value : string) {
    	this.loginForm.reset();
		this.registerUser.reset();
		this.forgetPasswordForm.reset();

    	switch (value) {
    		case 'login':
				this.l_r_tab = 'login';
				this.loginReg=true;
				this.forgetPassword=false
    			break;
    		case 'reg':
				this.l_r_tab = 'reg';
				this.loginReg=true
				this.forgetPassword=false;
				break;
			case 'forget':
				this.l_r_tab ='forget';
				this.loginReg=false;
				this.forgetPassword=true;				
				break;
    		default:
    			break;
    	}
    }

    public openLogoutPopUp(){
    	this.logout_modal_open.nativeElement.click();
    }

    public doLogOut() {
		this.signOut()
    	// body...
    	this.logout_modal_close.nativeElement.click();

    	this.toastr.success('Logged Out Successfully.');

    	this.appService.setUserData(null);

    	localStorage.removeItem('userData')

        localStorage.removeItem('token')

		this.router.navigate(['']);
		
		this.ngOnInit()
		this.socialiteData=null
		this.socialiteLoggedIn=false
    }

    isFieldValid(field: string) {
        if (!this.changePasswordFormSubmitted) {
            // if true...
            return !this.changePasswordForm.get(field).valid && this.changePasswordForm.get(field).touched;
        } else {
            // if false...
            return !this.changePasswordForm.get(field).valid;
        }
    }

    displayFieldCss(field: string) {
        return {
            'has-error': this.isFieldValid(field)
            // 'has-success': !this.isFieldValid(field),
        };
    }

    public doChangePassword (params : any) {
    	this.passwordNotMatchingFlag = false;
    	this.changePasswordFormSubmitted = false;

    	if(params.password !== params.password_confirmation){
    		this.passwordNotMatchingFlag = true;
    		return;
    	}

    	if (this.changePasswordForm.valid) {
    		try{
    			this.loader = true
	    		params.user_id = this.userData.id
	    		this.commonAuthService.changePassword(params).subscribe(result => {
		            if (result['status'] == 'success') {
		                this.loader = false;
		                this.toastr.success(result['message']);
						this.openCloseChangePwdPopUp('close')
						localStorage.removeItem('userData')
						localStorage.removeItem('token')
						this.appService.setUserData(null);
						this.router.navigate(['']);
						// $('#user_login').modal('show');
						this.appService.openLoginPopUp();

		            } else {
		            	this.loader = false;
		                this.toastr.error(result['message']);
		            }
		        }, error => {
		            this.toastr.error(error.message);
		            this.loader = false;
		        });
		    }catch(err){
		    	this.loader = false;
		    	this.toastr.error(err);
		    }
    	} else {
    		this.changePasswordFormSubmitted = true;
    		return;
    	}
    }

    openCloseChangePwdPopUp(flag){
    	switch (flag){
    		case 'close': 
	    			this.changePasswordFormSubmitted = false;
					this.changePasswordForm.reset();
					this.change_pwd_modal_close.nativeElement.click();
    			break;
    		default :
    			break;
		}
		
    }

    public doSearchByProductType(product_type_id : number) {
		this.router.navigate(['/search-product/'+product_type_id]);
	}

	public doSearchByCategory(category_id) {
		$('.navbar-toggle').click();
		this.router.navigate(['/search-product/0/'+category_id]);
	}

	redirectTowishlist ()
	{
		if (this.userData) {
			this.router.navigate(['/wishlist']);
		} else {
			this.toastr.warning('Please login first.');
			this.appService.openLoginPopUp();
		}
	}
}