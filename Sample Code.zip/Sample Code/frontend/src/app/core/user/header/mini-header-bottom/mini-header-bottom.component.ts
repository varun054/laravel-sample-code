import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { CoreService } from './../../../services/core.service';
import { AppService } from '../../../../app.service';
import { Router } from '@angular/router';
declare var $:any
@Component({
  selector: 'app-mini-header-bottom',
  templateUrl: './mini-header-bottom.component.html',
  styleUrls: ['./mini-header-bottom.component.css']
})

export class MiniHeaderBottomComponent implements OnInit {

	constructor(
		private toastr : ToastrService,
		private coreService:CoreService,
		private router:Router,
		private AppService : AppService
	) { }

	ngOnInit() {
	}
}