import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../modules/user/user.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-top-header',
  templateUrl: './top-header.component.html',
  styleUrls: ['./top-header.component.css']
})
export class TopHeaderComponent implements OnInit {

	header_contact_no_content;
	header_social_links_content;

  	constructor(
  		private UserService : UserService,
  		private ToastrService : ToastrService,
  	) {
  		localStorage.removeItem('CMS_data');
  	}

	ngOnInit() {
		this.getCMSData();
	}

	getCMSData()
	{
		this.UserService.getCMSData({'flags' : ['header_contact_no', 'header_social_links']}).subscribe(result=>{
			if(result['status']=='success')
			{
				this.header_contact_no_content = result['data']['header_contact_no'];

				this.header_social_links_content = result['data']['header_social_links'];
			}
			else
				this.ToastrService.error(result['message'])
		}, (error)=>{
			this.ToastrService.error(error.message)
		});
	}

}
