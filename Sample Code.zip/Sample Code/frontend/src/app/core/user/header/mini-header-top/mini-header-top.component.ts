import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../../app.service';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';
import { CoreService } from './../../../services/core.service';

@Component({
  selector: 'app-mini-header-top',
  templateUrl: './mini-header-top.component.html',
  styleUrls: ['./mini-header-top.component.css']
})

export class MiniHeaderTopComponent implements OnInit {

	public category_list;

	public searchBox : boolean = false;
	
	public search : any = {
		'text' : '',
		'category' : '',
	};

	public userData:any
	public userId:any
	laptopAndTablets:any=[]
	desktopAndAllInOnes:any=[]
	accessories:any=[]
	extendedWarranty:any=[]
	software:any=[]
	laptopAndTabletsLength:number
	desktopAndAllInOnesLength:number
	accessoriesLength:number
	extendedWarrantyLength:number
	softwareLength:number

 	constructor(
 		private toastr : ToastrService,
 		private AppService : AppService,
 		private router:Router,
 		private coreService:CoreService,
 		private ActivatedRoute : ActivatedRoute,
 	) { }

	ngOnInit()
	{
		let data = this.AppService.setGetSearchValue();
		
		if (data){
			this.search.category = (data.category_id == '0') ? '' : data.category_id;
			this.search.text = (data.search_text) ? data.search_text.split('++').join('/') : '';
			this.AppService.setGetSearchValue({'category_id' : '', 'search_text' : ''});
		}

		this.getCategoryList();
		this.getMegaCategory();
	}

	private getMegaCategory () {
		setTimeout(() => {
			this.laptopAndTablets = JSON.parse(localStorage.getItem('laptop'));
			this.laptopAndTabletsLength = (this.laptopAndTablets) ? this.laptopAndTablets.length : 0;
			
			this.desktopAndAllInOnes = JSON.parse(localStorage.getItem('desktop'));
			this.desktopAndAllInOnesLength = (this.desktopAndAllInOnes) ? this.desktopAndAllInOnes.length : 0;
			
			this.accessories = JSON.parse(localStorage.getItem('accessories'));
			this.accessoriesLength = (this.accessories) ? this.accessories.length : 0;

			this.extendedWarranty = JSON.parse(localStorage.getItem('extended_warranty'));
			this.extendedWarrantyLength = (this.extendedWarranty) ? this.extendedWarranty.length : 0;

			this.software = JSON.parse(localStorage.getItem('software'));
			this.softwareLength = (this.software) ? this.software.length : 0;
		}, 1000);		
	}

	private getCategoryList () {
        try{
            this.coreService.getCategoryList().subscribe(res => {
                if (res['status'] == 'success') {
                    this.category_list = res['data'];
                } else {
                    this.toastr.error(res['message']);
                }
            }, error => {
                this.toastr.error(error.message);
            });
        }catch(err){
            this.toastr.error(err);
        }
	}

	public doSearch()
	{	
		let category = (this.search.category) ? this.search.category : '0';

		this.search.text = this.search.text.split('/').join('++');
		
		this.router.navigate(['/search-product/0/'+category+'/'+this.search.text]);

		this.search.text = this.search.text.split('++').join('/');
	}

	public doSearchByCate(category_id : number)
	{
		this.router.navigate(['/search-product/0/'+category_id]);
	}

	public doSearchByProductType(product_type_id) {
		// body...
	}

	public showHideSearch() {
		// body...
		if (this.searchBox) {
			this.searchBox = false;
		}else{
			this.searchBox = true;
		}
	}	
}
