import {
    FormGroup,
    FormBuilder,
    Validators
} from '@angular/forms';
import {
    Component,
    OnInit,
    AfterViewInit
} from '@angular/core';
import {
    CoreService
} from '../../services/core.service';
import {
    ToastrService
} from 'ngx-toastr';
import {
    Router
} from '@angular/router';
import {
    ValidatorList
} from '../../../shared/validator.service';

import { UserService } from '../../../modules/user/user.service';
import { AppService } from '../../../app.service';
import { environment } from '../../../../environments/environment';

declare var $: any;

@Component({
    selector: 'app-footer',
    templateUrl: './footer.component.html',
    styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit, AfterViewInit
{
    recaptcha_site_key;
    public brands;
    subscriptionForm: FormGroup
    public brandPath;
    loader: boolean = false;
    bottom_footer_content;
    footer_logo_and_social_content;
    footer_subscription_content;
    userData : any;

    constructor(
        private coreService: CoreService,
        private toastr: ToastrService,
        private router: Router,
        private formBuilder: FormBuilder,
        private UserService: UserService,
        private AppService: AppService,
    ) {
        this.userData = JSON.parse(localStorage.getItem('userData'));

        this.recaptcha_site_key = environment.recaptcha_site_key;
    }
    
    public account_validation_messages = ValidatorList.account_validation_messages
    
    ngOnInit()
    {
        this.getBrands();

        this.getCMSData();

        this.subscriptionForm = this.formBuilder.group({
            email: ['', [Validators.required, ValidatorList.emailValidator]],
            recaptcha : [null, [Validators.required]],
        })

    }

    resolved(captchaResponse: string)
    {
        this.subscriptionForm.patchValue({
            recaptcha:1
        });
    }

    set_recaptcha()
    {
        if (this.subscriptionForm.get('recaptcha').value == 1 && this.subscriptionForm.get('email').invalid)
        {
            this.subscriptionForm.patchValue({
                recaptcha : null
            });
        }
    }

    getCMSData()
    {
        this.UserService.getCMSData({'flags' : ['footer_bottom', 'footer_logo_and_social', 'footer_subscription']}).subscribe(result=>{
            if(result['status']=='success')
            {
                this.bottom_footer_content = result['data']['footer_bottom'];
                this.footer_logo_and_social_content = result['data']['footer_logo_and_social'];
                this.footer_subscription_content = result['data']['footer_subscription'];
            }
            else
                this.toastr.error(result['message'])
        }, (error)=>{
            this.toastr.error(error.message)
        });
    }

    ngAfterViewInit ()
    {
    }

    loginValidateAllFormFields(formGroup: FormGroup) {
        Object.keys(this.subscriptionForm.controls).forEach(field => {
            const control = this.subscriptionForm.get(field);
            control.markAsTouched({
                onlySelf: true
            });
            control.markAsDirty({
                onlySelf: true
            });
        });
    }

    subscriptionFormSubmit() {
        if (this.subscriptionForm.valid) {
            this.loader = true;
            this.coreService.subscribeUser(this.subscriptionForm.value)
                .subscribe(result => {
                    if (result['status'] == 'success') {
                        this.toastr.success(result['message'])
                        this.loader = false;
                        this.subscriptionForm.reset();
                    } else {
                        this.loader = false;
                        this.toastr.warning(result['message']);
                        this.subscriptionForm.reset();
                    }
                }, (error) => {
                    this.loader = false;
                    this.toastr.error(error.message)
                })
        } else {
            this.loginValidateAllFormFields(this.subscriptionForm)
            return
        }
    }

    public getBrands() {
        try {
            this.coreService.getBrands().subscribe(res => {
                if (res['status'] == 'success') {
                    this.brands = res['data'];
                    this.brandPath = res['path'];
                } else {
                    this.toastr.error(res['message']);
                }
            }, error => {
                this.toastr.error(error.message);
            });
        } catch (err) {
            this.toastr.error(err);
        }
    }

    public onBrandClick(brand_id) {
        this.router.navigate(['/search-product/' + brand_id]);
    }

    /*doSearchByProductType(product_type_id : number) {
      this.router.navigate(['/search-product/'+product_type_id]);
    }*/

    public doSearchByCategory(category_id) {
        this.router.navigate(['/search-product/0/' + category_id]);
    }

    goto(flag)
    {
        if (!this.userData)
        {
            this.toastr.warning('Please login first !!!');

            this.AppService.openLoginPopUp();

            return;
        }

        if (flag == 'my_account')
        {
            this.router.navigate(['/user-profile']);
        }

        if (flag == 'order')
        {
            this.router.navigate(['/my-orders']);
        }
    }
}