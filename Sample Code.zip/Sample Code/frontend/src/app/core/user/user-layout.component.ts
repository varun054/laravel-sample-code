import {
    Component,
    OnInit
} from '@angular/core';

@Component({
    selector: 'app-user-layout',
    template: `
    	<app-top-header class="doNotPrint"></app-top-header>
    	<app-main-header class="doNotPrint"></app-main-header>
        <router-outlet></router-outlet>
    	<app-footer class="doNotPrint"></app-footer>
  `,
})
export class UserLayoutComponent implements OnInit {

    constructor() {}

    ngOnInit() {
    }
}