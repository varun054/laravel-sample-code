import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CoreService {

	private url = environment.url;
  	
  	constructor(private http:HttpClient) { }

  	getPhoneCodes(){
		return this.http.get(this.url+'master/get-phone-codes');
	}

	getCountryName(){
		return this.http.get(this.url+'master/get-country-names');
	}

	getBrands(){
		return this.http.get(this.url+'master/get-brands');
	}

	getCategoryList(){
		return this.http.get(this.url+'master/get-categories');
	}

	getwishListCount(value){
		return this.http.get(this.url+'user/wishlist/'+value)
	}

	getCategoryListCount(value){
		return this.http.get(this.url+'user/get-user-cart-data/'+value)
	}

	getFaqData(params){
	    return this.http.post(this.url+'faq/get-faq-data', params)
	}

	getAdminFaqData(params){
		return this.http.post(this.url+'faq/get-faq-data', params);
	}

	getMegaMenuData(category_id){
		if (category_id) {
			return this.http.get(this.url+'master/get-categories-children/'+category_id);
		}else{
	    	return this.http.get(this.url+'master/get-categories-children');
		}
	}

	subscribeUser(value){
		return this.http.post(this.url+'subscription/subscribe-user',value)
	}

	getChildCategory(value){
		return this.http.get(this.url+'master/get-categories-children/'+value);
	}
}
