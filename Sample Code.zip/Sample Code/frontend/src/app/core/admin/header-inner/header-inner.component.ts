import {
    Router
} from '@angular/router';
import {
    Component
} from '@angular/core';
import { environment } from '../../../../environments/environment';
import { AppService } from '../../../app.service';
import {ConfirmationService} from 'primeng/api';
@Component({
    selector: 'app-header-inner',
    templateUrl: './header-inner.component.html'
})

export class HeaderInnerComponent {

    
    public userData;

    constructor(private router: Router, private appService:AppService, private confirmationService:ConfirmationService)
    {
        this.userData = JSON.parse(localStorage.getItem('userData'));
    }

    ngOnInit(){
        this.appService.getUserData().subscribe((result)=>{
              this.userData=result
        });
    }

    signOut() {
        localStorage.removeItem('userData');
        localStorage.removeItem('token');
        this.router.navigate(['/admin/login']);
    }

    
  changePasswordPage(){
    this.router.navigate(['/admin/change-password'])
  }

  confirm() {
    
    this.confirmationService.confirm({
      message: 'Are you sure that you want to logged Out?',
      accept: () => {
        this.signOut()
          //Actual logic to perform a confirmation
      }
    });
  }
}
