import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ReplaySubject, BehaviorSubject } from 'rxjs';
import { environment } from '../environments/environment';
import { Router } from '@angular/router';
import {ToastrService} from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  url=environment.url
  public userData= new ReplaySubject<Object>();
  public wishListCount= new ReplaySubject<Object>();
  public cartListCount= new ReplaySubject<Object>();
  public sideBarId=new ReplaySubject<object>();
  public className=new ReplaySubject<object>();
  public open=new ReplaySubject<object>();
  // public searchData = new ReplaySubject<Object>();

  messageSource = new BehaviorSubject('');
  searchData = this.messageSource.asObservable();
  
  private search_value : any;

  envUserData:any

  constructor(private router:Router, private toastr : ToastrService) { }
  
  ngOnInit(){
    this.userData.next(this.envUserData);
  }

  setGetSearchValue(data = null)
  {
      if (data) {
          this.search_value = data;
      }else{
          return this.search_value;
      }
  }

  setUserData(value){
    this.userData.next(value);
  }

  getUserData(){
    return this.userData.asObservable();
  }

  openLoginPopUp(){
    this.open.next({});
  }

  openPopUp(){
    return this.open.asObservable();
  }

  setWishListCount(value){
    this.wishListCount.next(value)
  }

  getWishListCount(){
    return this.wishListCount.asObservable();
  }

  setCartListCount(value){
    this.cartListCount.next(value)
  }

  getCartListCount(){
    return this.cartListCount.asObservable();
  }

  // for search item update
  setSearchItem(value){
    this.messageSource.next(value);
  }

  setClassName(id,className){
    this.className.next(className)
    this.sideBarId.next(id)
  }

  getClassName(){
    return this.className.asObservable();
  }

  getSideBarId(){
    return this.sideBarId.asObservable();
  }

  unAuthorizedUserAccess(error, flag){
    if(error.status==401){
      localStorage.removeItem('userData')
      localStorage.removeItem('token')

      this.setUserData(null);

      if (flag == 'front') {
        this.router.navigate(['']);
      } else {
        this.router.navigate(['/admin/login']);
      }
    }
    else{
      this.toastr.error(error.message)
    }
  }
}
