import { AppService } from './app.service';
import { environment } from './../environments/environment';
import { Component, OnInit } from '@angular/core';
import { LayoutService } from 'angular-admin-lte';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  public customLayout: boolean;
  userData:any
  constructor(
    private layoutService: LayoutService, private appService:AppService
  ) {}

  ngOnInit() {
    this.layoutService.isCustomLayout.subscribe((value: boolean) => {
      this.customLayout = value;
    });
    
    // this.userData = environment.userData;
  }
}
